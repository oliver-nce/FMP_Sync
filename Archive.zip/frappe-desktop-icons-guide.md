# Frappe Desktop Icons Guide

## Overview

Desktop icons (also called "App Tiles") allow your Frappe app to appear on the main apps page, making it easily accessible to users. When configured, your app appears alongside built-in apps like Home, CRM, HR, and Accounting.

---

## How Desktop Icons Work

### The Configuration File

Desktop icons are configured in your app's **`hooks.py`** file using the `add_to_apps_screen` list.

**File Location:**
```
YourApp/your_app/hooks.py
```

For example, in the NCE_Sync app:
```
NCE_Sync/nce_sync/hooks.py
```

---

## Basic Configuration

### Step 1: Edit hooks.py

Open your `hooks.py` file and find (or add) the `add_to_apps_screen` section:

```python
# Each item in the list will be shown as an app in the apps page
add_to_apps_screen = [
	{
		"name": "nce_sync",
		"logo": "/assets/nce_sync/logo.png",
		"title": "NCE Sync",
		"route": "/nce_sync",
		"has_permission": "nce_sync.api.permission.has_app_permission"
	}
]
```

### Step 2: Understanding Each Field

| Field | Required | Description | Example |
|-------|----------|-------------|---------|
| `name` | Yes | Unique identifier for the app tile | `"nce_sync"` |
| `logo` | Yes | Path to the icon image (relative to `public/`) | `"/assets/nce_sync/logo.png"` |
| `title` | Yes | Display name shown under the icon | `"NCE Sync"` |
| `route` | Yes | URL path when users click the icon | `"/nce_sync"` |
| `has_permission` | No | Python path to permission check function | `"nce_sync.api.permission.has_app_permission"` |

---

## Route Options

The `route` field determines where clicking the icon takes the user.

### 1. **Workspace (Recommended)**
```python
"route": "/nce_sync"
```
Opens a Workspace dashboard with links, shortcuts, and cards.

**Requires:** A Workspace DocType named "NCE Sync" created in:
- UI: Setup → Workspace → New Workspace
- Or file: `nce_sync/workspace/nce_sync/nce_sync.json`

---

### 2. **DocType List View**
```python
"route": "/app/wp-tables"
```
Opens the list view of a specific DocType (shows all records).

---

### 3. **New Document Form**
```python
"route": "/app/wordpress-connection/new"
```
Opens a blank form to create a new document.

---

### 4. **Report**
```python
"route": "/app/query-report/Sync Status Report"
```
Opens a specific report.

---

### 5. **Custom Web Page**
```python
"route": "/nce_sync/dashboard"
```
Opens a custom HTML page from your `www/` folder.

**Requires:** File at `nce_sync/www/dashboard.html` or `dashboard.py`

---

## Adding the Logo

### Step 1: Create an Icon Image

**Requirements:**
- Format: PNG (recommended) or SVG
- Size: 100x100 pixels or larger (square)
- Background: Transparent or solid color
- File name: `logo.png` or similar

### Step 2: Place in Public Folder

Copy your icon to:
```
NCE_Sync/nce_sync/public/logo.png
```

### Step 3: Reference in hooks.py

```python
"logo": "/assets/nce_sync/logo.png"
```

**Note:** The path is automatically mapped:
- `/assets/nce_sync/` → `nce_sync/public/`

---

## Permission Control

### Option 1: No Permission Check (Public)
```python
{
	"name": "nce_sync",
	"logo": "/assets/nce_sync/logo.png",
	"title": "NCE Sync",
	"route": "/nce_sync"
	# No has_permission field = everyone can see it
}
```

### Option 2: Custom Permission Function
```python
{
	"name": "nce_sync",
	"logo": "/assets/nce_sync/logo.png",
	"title": "NCE Sync",
	"route": "/nce_sync",
	"has_permission": "nce_sync.api.permission.has_app_permission"
}
```

**Create the permission function:**

File: `nce_sync/api/permission.py`
```python
import frappe

def has_app_permission():
	"""Check if user has permission to see NCE Sync app"""
	# Option 1: Check role
	if "System Manager" in frappe.get_roles():
		return True
	
	# Option 2: Check custom permission
	if frappe.has_permission("WordPress Connection", "read"):
		return True
	
	return False
```

---

## Multiple Desktop Icons

You can add multiple icons for the same app:

```python
add_to_apps_screen = [
	# Main app workspace
	{
		"name": "nce_sync",
		"logo": "/assets/nce_sync/logo.png",
		"title": "NCE Sync",
		"route": "/nce_sync"
	},
	# Quick access to WP Tables
	{
		"name": "wp_tables",
		"logo": "/assets/nce_sync/wp_tables_icon.png",
		"title": "WP Tables",
		"route": "/app/wp-tables"
	},
	# Quick access to create connection
	{
		"name": "new_connection",
		"logo": "/assets/nce_sync/new_conn_icon.png",
		"title": "New Connection",
		"route": "/app/wordpress-connection/new"
	}
]
```

---

## Complete Example

### File: `NCE_Sync/nce_sync/hooks.py`

```python
app_name = "nce_sync"
app_title = "NCE Sync"
app_publisher = "Oliver Reid"
app_description = "For syncing WP tables and Frappe"
app_email = "oreid@firstgm.com"
app_license = "mit"

# Apps
# ------------------

# Each item in the list will be shown as an app in the apps page
add_to_apps_screen = [
	{
		"name": "nce_sync",
		"logo": "/assets/nce_sync/logo.png",
		"title": "NCE Sync",
		"route": "/nce_sync",
		"has_permission": "nce_sync.api.permission.has_app_permission"
	}
]

# ... rest of hooks.py
```

---

## Applying Changes

After editing `hooks.py`, you need to restart Frappe for changes to take effect:

### Method 1: Restart Bench (Development)
```bash
bench restart
```

### Method 2: Clear Cache + Restart (Production)
```bash
bench clear-cache
bench restart
```

### Method 3: Full Rebuild (If icon doesn't appear)
```bash
bench build
bench clear-cache
bench restart
```

---

## Troubleshooting

### Icon Doesn't Appear

**Check 1:** Verify the app is installed
```bash
bench list-apps
```

**Check 2:** Clear browser cache
- Hard refresh: Ctrl+Shift+R (Windows/Linux) or Cmd+Shift+R (Mac)

**Check 3:** Check permission function
- Make sure the permission function returns `True`
- Test in console:
```python
frappe.call('nce_sync.api.permission.has_app_permission')
```

**Check 4:** Verify logo path
- Make sure file exists at `nce_sync/public/logo.png`
- Check file permissions (should be readable)

---

### Icon Appears But Image Doesn't Load

**Fix 1:** Check logo path spelling
```python
"logo": "/assets/nce_sync/logo.png"  # Correct
"logo": "/assets/nce_sync/Logo.png"  # Wrong (case-sensitive)
```

**Fix 2:** Rebuild assets
```bash
bench build --app nce_sync
```

**Fix 3:** Check file format
- Use PNG or SVG
- Avoid spaces in filename

---

### Wrong Route / 404 Error

**Fix 1:** Create the Workspace

If using `"route": "/nce_sync"`, you need to create a Workspace:

1. Go to: **Desk → Setup → Workspace**
2. Click: **New**
3. Set:
   - Title: `NCE Sync`
   - Module: `NCE Sync`
   - Public: ✓ (checked)
4. Add shortcuts/links as needed
5. Save

**Fix 2:** Use correct DocType route format
```python
# Correct
"route": "/app/wp-tables"          # DocType: WP Tables

# Wrong
"route": "/app/WP Tables"          # Spaces not allowed
"route": "/wp-tables"              # Missing /app/
```

---

## Best Practices

### 1. **Use Workspaces for Main App Icon**
Workspaces provide the best user experience with customizable layouts, shortcuts, and quick access links.

### 2. **Keep Icon Simple**
- Use clear, recognizable imagery
- Avoid too much detail (icons are displayed small)
- Use high contrast colors

### 3. **Descriptive Titles**
- Keep titles short (1-3 words)
- Use title case: "NCE Sync" not "nce sync"

### 4. **Logical Route Names**
```python
# Good
"route": "/nce_sync"               # Matches app name
"route": "/app/wp-tables"          # Clear DocType reference

# Avoid
"route": "/stuff"                  # Unclear
"route": "/my-awesome-page-123"    # Too long
```

### 5. **Test Permissions**
Always test your permission function with different user roles to ensure proper access control.

---

## File Structure Reference

```
NCE_Sync/                                    # App directory
├── nce_sync/                                # Python module
│   ├── hooks.py                             # ← Configure icons here
│   ├── public/                              # Static assets
│   │   └── logo.png                         # ← Place icon here
│   ├── workspace/                           # Workspace definitions
│   │   └── nce_sync/
│   │       └── nce_sync.json                # ← Workspace config
│   └── api/
│       └── permission.py                    # ← Permission functions
└── ...
```

---

## Summary Checklist

- [ ] Edit `hooks.py` and add/uncomment `add_to_apps_screen`
- [ ] Add logo image to `public/` folder
- [ ] Set correct route (workspace, DocType, or page)
- [ ] Configure permission function (optional)
- [ ] Run `bench restart`
- [ ] Clear browser cache
- [ ] Test with different user roles
- [ ] Verify icon appears on apps page
- [ ] Click icon and verify correct destination

---

## Additional Resources

- [Frappe Framework Documentation](https://frappeframework.com/docs)
- [Workspace Documentation](https://frappeframework.com/docs/user/en/desk/workspace)
- [Hooks Reference](https://frappeframework.com/docs/user/en/python-api/hooks)

---

**Last Updated:** February 2026  
**App Example:** NCE_Sync
