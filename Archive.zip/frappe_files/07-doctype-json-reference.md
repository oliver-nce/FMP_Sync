# DocType JSON Reference

This document covers the complete JSON schema and structure for defining DocTypes in Frappe applications. For Python controllers and app structure, see `08-python-controllers-app-structure.md`.

## 1. Overview

### What is a DocType JSON File

A DocType JSON file is the declarative definition of a database model in Frappe. It defines the schema (fields), permissions, naming rules, and behavior settings for a document type. Frappe reads this JSON file to create database tables, generate forms, and enforce business rules.

### File Location

DocType JSON files follow a strict directory structure:

```
apps/
└── your_app/
    └── your_app/
        └── module_name/
            └── doctype/
                └── doctype_name/
                    ├── doctype_name.json      # Schema definition
                    ├── doctype_name.py        # Python controller
                    ├── doctype_name.js        # Client script
                    └── test_doctype_name.py   # Tests
```

The folder name and JSON filename must match the DocType name in lowercase with underscores replacing spaces.

### Basic Anatomy

```json
{
    "name": "My DocType",
    "module": "My Module",
    "doctype": "DocType",
    "fields": [...],
    "permissions": [...],
    "autoname": "field:title",
    "sort_field": "modified",
    "sort_order": "DESC"
}
```

---

## 2. Top-Level DocType Fields

| Field | Type | Description | Example |
|-------|------|-------------|---------|
| `name` | String | Unique identifier for the DocType | `"Customer"` |
| `module` | String | Module this DocType belongs to | `"Selling"` |
| `doctype` | String | Always `"DocType"` for DocType definitions | `"DocType"` |
| `custom` | 0/1 | Whether this is a Custom DocType (created via UI) | `0` |
| `istable` | 0/1 | Whether this is a child table DocType | `0` |
| `issingle` | 0/1 | Whether only one record exists (settings) | `0` |
| `is_submittable` | 0/1 | Whether documents can be submitted/cancelled | `1` |
| `is_tree` | 0/1 | Whether this DocType uses tree/hierarchy structure | `0` |
| `is_virtual` | 0/1 | Whether this DocType has no database table | `0` |
| `autoname` | String | Naming rule for new documents | `"naming_series:"` |
| `naming_rule` | String | Human-readable naming rule description | `"By fieldname"` |
| `title_field` | String | Field to use as document title | `"customer_name"` |
| `search_fields` | String | Comma-separated fields for search | `"customer_name,email"` |
| `sort_field` | String | Default sort field | `"modified"` |
| `sort_order` | String | Default sort order | `"DESC"` |
| `track_changes` | 0/1 | Track field-level changes in Version | `1` |
| `track_seen` | 0/1 | Track which users have seen document | `0` |
| `track_views` | 0/1 | Count document views | `0` |
| `allow_rename` | 0/1 | Allow document renaming | `1` |
| `allow_copy` | 0/1 | Allow duplicating documents | `1` |
| `allow_import` | 0/1 | Allow data import | `1` |
| `show_name_in_global_search` | 0/1 | Include in global search | `1` |
| `show_preview_popup` | 0/1 | Show preview on hover in links | `1` |
| `quick_entry` | 0/1 | Enable quick entry dialog | `0` |
| `migration_hash` | String | Hash for migration tracking (auto-generated) | `"abc123..."` |
| `engine` | String | Database engine | `"InnoDB"` |
| `beta` | 0/1 | Mark as beta feature | `0` |
| `image_field` | String | Field containing document image | `"image"` |
| `max_attachments` | Int | Maximum file attachments allowed | `10` |
| `document_type` | String | Classification: Document, Setup, Master, etc. | `"Document"` |
| `icon` | String | FontAwesome icon class | `"fa fa-user"` |
| `color` | String | Icon color | `"#FF5733"` |
| `description` | String | DocType description | `"Manage customers"` |
| `default_print_format` | String | Default print format name | `"Standard"` |
| `read_only` | 0/1 | Make entire DocType read-only | `0` |
| `in_create` | 0/1 | Document is being created (internal) | `0` |
| `actions` | Array | Custom action buttons | `[]` |
| `links` | Array | Dashboard links to related DocTypes | `[]` |
| `states` | Array | Document state configurations | `[]` |

---

## 3. All Field Types

### Data

Single-line text input for short strings.

**When to use:** Names, titles, short identifiers, email addresses, phone numbers.

| Property | Required | Description |
|----------|----------|-------------|
| `fieldname` | Yes | Database column name |
| `fieldtype` | Yes | `"Data"` |
| `label` | Yes | Display label |
| `options` | No | Validation: `"Email"`, `"Phone"`, `"URL"`, `"Name"` |
| `length` | No | Maximum character length (default 140) |

```json
{
    "fieldname": "email_address",
    "fieldtype": "Data",
    "label": "Email Address",
    "options": "Email",
    "reqd": 1
}
```

### Small Text

Multi-line text for short paragraphs (stored as TEXT).

**When to use:** Short descriptions, addresses, notes under 500 characters.

```json
{
    "fieldname": "short_description",
    "fieldtype": "Small Text",
    "label": "Short Description"
}
```

### Text

Multi-line plain text (stored as TEXT).

**When to use:** Longer plain text content, code snippets, logs.

```json
{
    "fieldname": "notes",
    "fieldtype": "Text",
    "label": "Notes"
}
```

### Text Editor

Rich text editor with formatting toolbar (stored as LONGTEXT).

**When to use:** Formatted content, emails, descriptions with bold/italic/lists.

```json
{
    "fieldname": "description",
    "fieldtype": "Text Editor",
    "label": "Description"
}
```

### Long Text

Plain text for very large content (stored as LONGTEXT).

**When to use:** Large plain text, JSON data, logs.

```json
{
    "fieldname": "raw_data",
    "fieldtype": "Long Text",
    "label": "Raw Data"
}
```

### Code

Code editor with syntax highlighting.

**When to use:** Python, JavaScript, SQL, JSON, or any code.

| Property | Required | Description |
|----------|----------|-------------|
| `options` | No | Language: `"Python"`, `"JavaScript"`, `"JSON"`, `"HTML"`, `"CSS"`, `"SQL"` |

```json
{
    "fieldname": "script",
    "fieldtype": "Code",
    "label": "Script",
    "options": "Python"
}
```

### HTML

Read-only HTML content display.

**When to use:** Displaying formatted content, help text, embedded widgets.

```json
{
    "fieldname": "help_html",
    "fieldtype": "HTML",
    "label": "Help",
    "options": "<p>Enter customer details below.</p>"
}
```

### Markdown

Markdown text editor.

**When to use:** Documentation, README content, formatted text with Markdown.

```json
{
    "fieldname": "readme",
    "fieldtype": "Markdown",
    "label": "README"
}
```

### Link

Reference to another DocType (foreign key).

**When to use:** Relating documents, selecting from master data.

| Property | Required | Description |
|----------|----------|-------------|
| `options` | Yes | Target DocType name |

```json
{
    "fieldname": "customer",
    "fieldtype": "Link",
    "label": "Customer",
    "options": "Customer",
    "reqd": 1
}
```

### Dynamic Link

Link where target DocType is determined by another field.

**When to use:** Polymorphic references (e.g., link to Customer OR Supplier).

| Property | Required | Description |
|----------|----------|-------------|
| `options` | Yes | Fieldname containing the DocType name |

```json
{
    "fieldname": "party_type",
    "fieldtype": "Link",
    "label": "Party Type",
    "options": "DocType"
},
{
    "fieldname": "party",
    "fieldtype": "Dynamic Link",
    "label": "Party",
    "options": "party_type"
}
```

### Select

Dropdown selection from predefined options.

**When to use:** Status fields, type selections, any enumerated choices.

| Property | Required | Description |
|----------|----------|-------------|
| `options` | Yes | Newline-separated list of options |

```json
{
    "fieldname": "status",
    "fieldtype": "Select",
    "label": "Status",
    "options": "Draft\nPending\nApproved\nRejected",
    "default": "Draft"
}
```

### Check

Boolean checkbox (stores 0 or 1).

**When to use:** Yes/no flags, toggles, boolean states.

```json
{
    "fieldname": "is_active",
    "fieldtype": "Check",
    "label": "Is Active",
    "default": "1"
}
```

### Int

Integer number field.

**When to use:** Quantities, counts, whole numbers.

```json
{
    "fieldname": "quantity",
    "fieldtype": "Int",
    "label": "Quantity",
    "default": "0"
}
```

### Float

Decimal number field.

**When to use:** Measurements, rates, decimal values.

| Property | Required | Description |
|----------|----------|-------------|
| `precision` | No | Decimal places (default from System Settings) |

```json
{
    "fieldname": "weight",
    "fieldtype": "Float",
    "label": "Weight (kg)",
    "precision": "3"
}
```

### Currency

Monetary amount with currency formatting.

**When to use:** Prices, amounts, monetary values.

| Property | Required | Description |
|----------|----------|-------------|
| `options` | No | Field containing currency code, or fixed currency |
| `precision` | No | Decimal places |

```json
{
    "fieldname": "grand_total",
    "fieldtype": "Currency",
    "label": "Grand Total",
    "options": "currency",
    "precision": "2"
}
```

### Percent

Percentage value (0-100).

**When to use:** Discount rates, completion percentages.

```json
{
    "fieldname": "discount_percent",
    "fieldtype": "Percent",
    "label": "Discount %"
}
```

### Date

Date picker (stores as YYYY-MM-DD).

**When to use:** Birthdates, due dates, any date without time.

```json
{
    "fieldname": "due_date",
    "fieldtype": "Date",
    "label": "Due Date"
}
```

### Datetime

Date and time picker (stores as YYYY-MM-DD HH:MM:SS).

**When to use:** Timestamps, scheduled times, appointments.

```json
{
    "fieldname": "scheduled_time",
    "fieldtype": "Datetime",
    "label": "Scheduled Time"
}
```

### Time

Time picker (stores as HH:MM:SS).

**When to use:** Durations, times without dates.

```json
{
    "fieldname": "start_time",
    "fieldtype": "Time",
    "label": "Start Time"
}
```

### Duration

Time duration in seconds with human-readable display.

**When to use:** Task duration, elapsed time, time tracking.

```json
{
    "fieldname": "time_spent",
    "fieldtype": "Duration",
    "label": "Time Spent"
}
```

### Table

Child table containing multiple rows of another DocType.

**When to use:** Line items, detail rows, one-to-many relationships.

| Property | Required | Description |
|----------|----------|-------------|
| `options` | Yes | Child DocType name (must have `istable: 1`) |

```json
{
    "fieldname": "items",
    "fieldtype": "Table",
    "label": "Items",
    "options": "Sales Order Item",
    "reqd": 1
}
```

### Table MultiSelect

Multi-select using a link table.

**When to use:** Many-to-many relationships, selecting multiple records.

| Property | Required | Description |
|----------|----------|-------------|
| `options` | Yes | Child DocType name containing Link field |

```json
{
    "fieldname": "users",
    "fieldtype": "Table MultiSelect",
    "label": "Assigned Users",
    "options": "Task User"
}
```

### Attach

File attachment field.

**When to use:** Any file type attachment.

```json
{
    "fieldname": "attachment",
    "fieldtype": "Attach",
    "label": "Attachment"
}
```

### Attach Image

Image file attachment with preview.

**When to use:** Photos, logos, any image content.

```json
{
    "fieldname": "photo",
    "fieldtype": "Attach Image",
    "label": "Photo"
}
```

### Image

Display-only image field (reads from another Attach Image field).

**When to use:** Displaying an image stored in another field.

| Property | Required | Description |
|----------|----------|-------------|
| `options` | Yes | Fieldname of Attach Image field |

```json
{
    "fieldname": "image_preview",
    "fieldtype": "Image",
    "label": "Preview",
    "options": "photo"
}
```

### Signature

Digital signature capture field.

**When to use:** Approvals, acknowledgments, sign-off.

```json
{
    "fieldname": "signature",
    "fieldtype": "Signature",
    "label": "Signature"
}
```

### Color

Color picker with hex value.

**When to use:** Theme colors, category colors, visual markers.

```json
{
    "fieldname": "color",
    "fieldtype": "Color",
    "label": "Color",
    "default": "#3498db"
}
```

### Icon

Icon picker (FontAwesome icons).

**When to use:** Visual identifiers, category icons.

```json
{
    "fieldname": "icon",
    "fieldtype": "Icon",
    "label": "Icon"
}
```

### Barcode

Barcode display field.

**When to use:** Product barcodes, QR codes.

```json
{
    "fieldname": "barcode",
    "fieldtype": "Barcode",
    "label": "Barcode"
}
```

### Rating

Star rating field (0-5 or custom).

**When to use:** Reviews, satisfaction scores, priority ratings.

```json
{
    "fieldname": "rating",
    "fieldtype": "Rating",
    "label": "Rating"
}
```

### Password

Masked password input (stored encrypted).

**When to use:** API keys, secrets, credentials.

```json
{
    "fieldname": "api_key",
    "fieldtype": "Password",
    "label": "API Key"
}
```

### Read Only

Computed/display-only field value.

**When to use:** Calculated values, derived data.

```json
{
    "fieldname": "full_name",
    "fieldtype": "Read Only",
    "label": "Full Name"
}
```

### Button

Clickable button (triggers client script).

**When to use:** Triggering actions, workflows, custom functions.

```json
{
    "fieldname": "fetch_data",
    "fieldtype": "Button",
    "label": "Fetch Data"
}
```

### Heading

Section heading text.

**When to use:** Visual organization, labeling sections.

```json
{
    "fieldname": "contact_heading",
    "fieldtype": "Heading",
    "label": "Contact Information"
}
```

### Section Break

Creates a new section/card in the form.

**When to use:** Organizing fields into logical groups.

| Property | Required | Description |
|----------|----------|-------------|
| `collapsible` | No | Whether section can collapse |
| `collapsible_depends_on` | No | Condition for collapse state |

```json
{
    "fieldname": "address_section",
    "fieldtype": "Section Break",
    "label": "Address Details",
    "collapsible": 1
}
```

### Column Break

Creates columns within a section.

**When to use:** Side-by-side field layout.

```json
{
    "fieldname": "column_break_1",
    "fieldtype": "Column Break"
}
```

### Tab Break

Creates a new tab in the form.

**When to use:** Organizing many fields into tabs.

```json
{
    "fieldname": "details_tab",
    "fieldtype": "Tab Break",
    "label": "Details"
}
```

### HTML Editor

Full HTML editor (TinyMCE-like).

**When to use:** Complex formatted content, templates.

```json
{
    "fieldname": "email_template",
    "fieldtype": "HTML Editor",
    "label": "Email Template"
}
```

### Geolocation

Map-based location picker with coordinates.

**When to use:** Addresses, locations, mapping.

```json
{
    "fieldname": "location",
    "fieldtype": "Geolocation",
    "label": "Location"
}
```

### JSON

JSON data field with editor.

**When to use:** Structured data, configuration, API responses.

```json
{
    "fieldname": "metadata",
    "fieldtype": "JSON",
    "label": "Metadata"
}
```

---

## 4. Field Properties - Complete Reference

| Property | Type | Description | Example |
|----------|------|-------------|---------|
| `fieldname` | String | Database column name (lowercase, underscores) | `"customer_name"` |
| `fieldtype` | String | Field type from list above | `"Data"` |
| `label` | String | Display label | `"Customer Name"` |
| `reqd` | 0/1 | Field is mandatory | `1` |
| `unique` | 0/1 | Value must be unique | `1` |
| `default` | String | Default value | `"Draft"` |
| `options` | String | Type-specific options (Link target, Select options, etc.) | `"Customer"` |
| `read_only` | 0/1 | Field is not editable | `0` |
| `hidden` | 0/1 | Field is hidden from form | `0` |
| `bold` | 0/1 | Label is bold | `0` |
| `depends_on` | String | Condition for field visibility | `"eval:doc.is_active==1"` |
| `mandatory_depends_on` | String | Condition for mandatory state | `"eval:doc.status=='Active'"` |
| `read_only_depends_on` | String | Condition for read-only state | `"eval:doc.docstatus==1"` |
| `fetch_from` | String | Auto-fetch from linked document | `"customer.customer_name"` |
| `fetch_if_empty` | 0/1 | Only fetch if field is empty | `1` |
| `in_list_view` | 0/1 | Show in list view | `1` |
| `in_standard_filter` | 0/1 | Show in filter sidebar | `1` |
| `in_global_search` | 0/1 | Include in global search | `1` |
| `in_preview` | 0/1 | Show in preview popup | `0` |
| `search_index` | 0/1 | Create database index | `1` |
| `permlevel` | Int | Permission level (0-9) | `0` |
| `precision` | String | Decimal precision | `"2"` |
| `length` | Int | Max character length (Data fields) | `140` |
| `description` | String | Help text below field | `"Enter full name"` |
| `translatable` | 0/1 | Value can be translated | `1` |
| `allow_on_submit` | 0/1 | Editable after submit | `0` |
| `collapsible` | 0/1 | Section is collapsible | `1` |
| `collapsible_depends_on` | String | Condition for collapsed state | `"eval:doc.items.length>5"` |
| `columns` | Int | Column width in child table (1-10) | `2` |
| `width` | String | CSS width for child table column | `"150px"` |
| `print_hide` | 0/1 | Hide in print format | `0` |
| `report_hide` | 0/1 | Hide in reports | `0` |
| `no_copy` | 0/1 | Don't copy when duplicating | `1` |
| `allow_bulk_edit` | 0/1 | Allow bulk edit in list view | `1` |
| `set_only_once` | 0/1 | Can only be set during creation | `1` |
| `ignore_user_permissions` | 0/1 | Bypass user permission filters | `0` |
| `ignore_xss_filter` | 0/1 | Allow HTML (security risk) | `0` |
| `non_negative` | 0/1 | Number must be >= 0 | `1` |
| `print_width` | String | Width in print format | `"100px"` |
| `print_hide_if_no_value` | 0/1 | Hide in print if empty | `1` |

### Conditional Expressions

The `depends_on`, `mandatory_depends_on`, and `read_only_depends_on` properties accept these formats:

```json
// Simple field check
"depends_on": "is_active"

// Eval expression
"depends_on": "eval:doc.status=='Active'"

// Multiple conditions
"depends_on": "eval:doc.status=='Active' && doc.is_verified==1"

// Check child table length
"depends_on": "eval:doc.items && doc.items.length > 0"

// Check user role
"depends_on": "eval:frappe.user_roles.includes('System Manager')"
```

---

## 5. Naming Rules

### autoname Options

| Pattern | Description | Example Result |
|---------|-------------|----------------|
| `field:fieldname` | Use field value as name | `field:title` → "My Document" |
| `naming_series:` | User-selected series | `INV-2024-0001` |
| `Prompt` | Ask user for name | User enters name |
| `format:XXX-{####}` | Fixed format with counter | `ORD-0001` |
| `format:XXX-{YYYY}-{####}` | Format with year | `ORD-2024-0001` |
| `format:XXX-{MM}-{####}` | Format with month | `ORD-01-0001` |
| `format:{field1}-{####}` | Format with field | `CUST-0001` |
| `hash` | Random hash | `a1b2c3d4e5` |
| `autoincrement` | Auto-incrementing integer | `1`, `2`, `3` |
| `[fieldname].#####` | Field value with counter | `PROJ.00001` |

### Format Placeholders

| Placeholder | Description |
|-------------|-------------|
| `{####}` | Zero-padded counter (4 digits) |
| `{#####}` | Zero-padded counter (5 digits) |
| `{YYYY}` | 4-digit year |
| `{YY}` | 2-digit year |
| `{MM}` | 2-digit month |
| `{DD}` | 2-digit day |
| `{fieldname}` | Value of a field |

```json
{
    "autoname": "format:INV-{YYYY}-{MM}-{#####}",
    "naming_rule": "Expression"
}
```

### Naming Series Configuration

When using `naming_series:`, create a "Naming Series" option:

```json
{
    "fieldname": "naming_series",
    "fieldtype": "Select",
    "label": "Naming Series",
    "options": "INV-.YYYY.-\nSINV-.YYYY.-",
    "default": "INV-.YYYY.-",
    "reqd": 1,
    "set_only_once": 1
}
```

---

## 6. Permissions Structure

Permissions define role-based access control for the DocType.

```json
{
    "permissions": [
        {
            "role": "System Manager",
            "permlevel": 0,
            "read": 1,
            "write": 1,
            "create": 1,
            "delete": 1,
            "submit": 1,
            "cancel": 1,
            "amend": 1,
            "email": 1,
            "print": 1,
            "share": 1,
            "export": 1,
            "import": 1,
            "report": 1,
            "set_user_permissions": 1
        },
        {
            "role": "Sales User",
            "permlevel": 0,
            "read": 1,
            "write": 1,
            "create": 1,
            "delete": 0,
            "submit": 0,
            "if_owner": 1
        }
    ]
}
```

### Permission Properties

| Property | Type | Description |
|----------|------|-------------|
| `role` | String | Role name | 
| `permlevel` | Int | Permission level (0-9) |
| `read` | 0/1 | Can view documents |
| `write` | 0/1 | Can edit documents |
| `create` | 0/1 | Can create new documents |
| `delete` | 0/1 | Can delete documents |
| `submit` | 0/1 | Can submit documents |
| `cancel` | 0/1 | Can cancel submitted documents |
| `amend` | 0/1 | Can amend cancelled documents |
| `email` | 0/1 | Can email documents |
| `print` | 0/1 | Can print documents |
| `share` | 0/1 | Can share documents |
| `export` | 0/1 | Can export data |
| `import` | 0/1 | Can import data |
| `report` | 0/1 | Can view reports |
| `if_owner` | 0/1 | Only applies to own documents |
| `select` | 0/1 | Can select in Link fields |
| `set_user_permissions` | 0/1 | Can set user permissions |

### Permission Levels

Fields can have different permission levels (0-9). Users need the corresponding permlevel permission to access those fields.

```json
{
    "fieldname": "salary",
    "fieldtype": "Currency",
    "label": "Salary",
    "permlevel": 1
}
```

```json
{
    "permissions": [
        {
            "role": "HR Manager",
            "permlevel": 0,
            "read": 1,
            "write": 1
        },
        {
            "role": "HR Manager",
            "permlevel": 1,
            "read": 1,
            "write": 1
        }
    ]
}
```

---

## 7. Complete Examples

### Example 1: Simple DocType

A basic "Product Category" DocType with simple naming and fields.

```json
{
    "name": "Product Category",
    "module": "Inventory",
    "doctype": "DocType",
    "engine": "InnoDB",
    "track_changes": 1,
    "autoname": "field:category_name",
    "naming_rule": "By fieldname",
    "title_field": "category_name",
    "search_fields": "category_name,description",
    "sort_field": "category_name",
    "sort_order": "ASC",
    "allow_rename": 1,
    "allow_copy": 1,
    "allow_import": 1,
    "show_name_in_global_search": 1,
    "fields": [
        {
            "fieldname": "category_name",
            "fieldtype": "Data",
            "label": "Category Name",
            "reqd": 1,
            "unique": 1,
            "in_list_view": 1,
            "in_standard_filter": 1
        },
        {
            "fieldname": "parent_category",
            "fieldtype": "Link",
            "label": "Parent Category",
            "options": "Product Category",
            "in_list_view": 1
        },
        {
            "fieldname": "column_break_1",
            "fieldtype": "Column Break"
        },
        {
            "fieldname": "is_active",
            "fieldtype": "Check",
            "label": "Is Active",
            "default": "1"
        },
        {
            "fieldname": "color",
            "fieldtype": "Color",
            "label": "Color"
        },
        {
            "fieldname": "section_break_1",
            "fieldtype": "Section Break",
            "label": "Description"
        },
        {
            "fieldname": "description",
            "fieldtype": "Small Text",
            "label": "Description"
        }
    ],
    "permissions": [
        {
            "role": "System Manager",
            "read": 1,
            "write": 1,
            "create": 1,
            "delete": 1,
            "export": 1,
            "import": 1
        },
        {
            "role": "Stock User",
            "read": 1,
            "write": 1,
            "create": 1,
            "export": 1
        }
    ]
}
```

### Example 2: Complex DocType with Child Table

A "Purchase Order" DocType with child table, conditional fields, and advanced features.

```json
{
    "name": "Purchase Order",
    "module": "Buying",
    "doctype": "DocType",
    "engine": "InnoDB",
    "is_submittable": 1,
    "track_changes": 1,
    "autoname": "naming_series:",
    "naming_rule": "By \"Naming Series\" field",
    "title_field": "supplier_name",
    "search_fields": "supplier,supplier_name,status",
    "sort_field": "modified",
    "sort_order": "DESC",
    "show_name_in_global_search": 1,
    "fields": [
        {
            "fieldname": "naming_series",
            "fieldtype": "Select",
            "label": "Series",
            "options": "PO-.YYYY.-\nPUR-ORD-.YYYY.-",
            "default": "PO-.YYYY.-",
            "reqd": 1,
            "set_only_once": 1
        },
        {
            "fieldname": "supplier",
            "fieldtype": "Link",
            "label": "Supplier",
            "options": "Supplier",
            "reqd": 1,
            "in_list_view": 1,
            "in_standard_filter": 1
        },
        {
            "fieldname": "supplier_name",
            "fieldtype": "Data",
            "label": "Supplier Name",
            "fetch_from": "supplier.supplier_name",
            "read_only": 1
        },
        {
            "fieldname": "column_break_1",
            "fieldtype": "Column Break"
        },
        {
            "fieldname": "transaction_date",
            "fieldtype": "Date",
            "label": "Date",
            "reqd": 1,
            "default": "Today",
            "in_list_view": 1
        },
        {
            "fieldname": "delivery_date",
            "fieldtype": "Date",
            "label": "Required By"
        },
        {
            "fieldname": "status",
            "fieldtype": "Select",
            "label": "Status",
            "options": "Draft\nPending Approval\nApproved\nReceived\nCancelled",
            "default": "Draft",
            "read_only": 1,
            "in_list_view": 1,
            "in_standard_filter": 1
        },
        {
            "fieldname": "items_section",
            "fieldtype": "Section Break",
            "label": "Items"
        },
        {
            "fieldname": "items",
            "fieldtype": "Table",
            "label": "Items",
            "options": "Purchase Order Item",
            "reqd": 1
        },
        {
            "fieldname": "totals_section",
            "fieldtype": "Section Break",
            "label": "Totals"
        },
        {
            "fieldname": "total_qty",
            "fieldtype": "Float",
            "label": "Total Quantity",
            "read_only": 1
        },
        {
            "fieldname": "column_break_totals",
            "fieldtype": "Column Break"
        },
        {
            "fieldname": "grand_total",
            "fieldtype": "Currency",
            "label": "Grand Total",
            "read_only": 1,
            "in_list_view": 1
        },
        {
            "fieldname": "tax_section",
            "fieldtype": "Section Break",
            "label": "Tax Details",
            "collapsible": 1,
            "depends_on": "eval:doc.apply_tax==1"
        },
        {
            "fieldname": "apply_tax",
            "fieldtype": "Check",
            "label": "Apply Tax"
        },
        {
            "fieldname": "tax_rate",
            "fieldtype": "Percent",
            "label": "Tax Rate",
            "depends_on": "eval:doc.apply_tax==1",
            "mandatory_depends_on": "eval:doc.apply_tax==1"
        },
        {
            "fieldname": "tax_amount",
            "fieldtype": "Currency",
            "label": "Tax Amount",
            "read_only": 1,
            "depends_on": "eval:doc.apply_tax==1"
        },
        {
            "fieldname": "terms_tab",
            "fieldtype": "Tab Break",
            "label": "Terms & Notes"
        },
        {
            "fieldname": "terms",
            "fieldtype": "Text Editor",
            "label": "Terms and Conditions"
        },
        {
            "fieldname": "notes",
            "fieldtype": "Small Text",
            "label": "Notes"
        },
        {
            "fieldname": "amended_from",
            "fieldtype": "Link",
            "label": "Amended From",
            "options": "Purchase Order",
            "read_only": 1,
            "no_copy": 1,
            "print_hide": 1
        }
    ],
    "permissions": [
        {
            "role": "System Manager",
            "permlevel": 0,
            "read": 1,
            "write": 1,
            "create": 1,
            "delete": 1,
            "submit": 1,
            "cancel": 1,
            "amend": 1,
            "print": 1,
            "email": 1,
            "share": 1,
            "export": 1,
            "import": 1
        },
        {
            "role": "Purchase User",
            "permlevel": 0,
            "read": 1,
            "write": 1,
            "create": 1,
            "submit": 1,
            "print": 1,
            "email": 1
        },
        {
            "role": "Purchase Manager",
            "permlevel": 0,
            "read": 1,
            "write": 1,
            "create": 1,
            "delete": 1,
            "submit": 1,
            "cancel": 1,
            "amend": 1,
            "print": 1,
            "email": 1,
            "share": 1,
            "export": 1
        }
    ]
}
```

**Child Table: Purchase Order Item**

```json
{
    "name": "Purchase Order Item",
    "module": "Buying",
    "doctype": "DocType",
    "istable": 1,
    "engine": "InnoDB",
    "fields": [
        {
            "fieldname": "item",
            "fieldtype": "Link",
            "label": "Item",
            "options": "Item",
            "reqd": 1,
            "in_list_view": 1,
            "columns": 3
        },
        {
            "fieldname": "item_name",
            "fieldtype": "Data",
            "label": "Item Name",
            "fetch_from": "item.item_name",
            "read_only": 1,
            "in_list_view": 1,
            "columns": 2
        },
        {
            "fieldname": "qty",
            "fieldtype": "Float",
            "label": "Quantity",
            "reqd": 1,
            "in_list_view": 1,
            "columns": 1
        },
        {
            "fieldname": "rate",
            "fieldtype": "Currency",
            "label": "Rate",
            "reqd": 1,
            "in_list_view": 1,
            "columns": 2
        },
        {
            "fieldname": "amount",
            "fieldtype": "Currency",
            "label": "Amount",
            "read_only": 1,
            "in_list_view": 1,
            "columns": 2
        }
    ],
    "permissions": []
}
```

### Example 3: Tree DocType

An "Account" DocType with tree/hierarchy structure.

```json
{
    "name": "Account",
    "module": "Accounts",
    "doctype": "DocType",
    "engine": "InnoDB",
    "is_tree": 1,
    "nsm_parent_field": "parent_account",
    "autoname": "field:account_name",
    "naming_rule": "By fieldname",
    "title_field": "account_name",
    "search_fields": "account_name,account_number,account_type",
    "sort_field": "lft",
    "sort_order": "ASC",
    "allow_rename": 1,
    "track_changes": 1,
    "fields": [
        {
            "fieldname": "account_name",
            "fieldtype": "Data",
            "label": "Account Name",
            "reqd": 1,
            "in_list_view": 1
        },
        {
            "fieldname": "account_number",
            "fieldtype": "Data",
            "label": "Account Number",
            "in_list_view": 1
        },
        {
            "fieldname": "column_break_1",
            "fieldtype": "Column Break"
        },
        {
            "fieldname": "parent_account",
            "fieldtype": "Link",
            "label": "Parent Account",
            "options": "Account",
            "ignore_user_permissions": 1
        },
        {
            "fieldname": "is_group",
            "fieldtype": "Check",
            "label": "Is Group",
            "bold": 1
        },
        {
            "fieldname": "section_break_1",
            "fieldtype": "Section Break"
        },
        {
            "fieldname": "account_type",
            "fieldtype": "Select",
            "label": "Account Type",
            "options": "\nAsset\nLiability\nEquity\nIncome\nExpense",
            "in_list_view": 1,
            "in_standard_filter": 1
        },
        {
            "fieldname": "root_type",
            "fieldtype": "Select",
            "label": "Root Type",
            "options": "\nAsset\nLiability\nEquity\nIncome\nExpense",
            "read_only": 1
        },
        {
            "fieldname": "balance_must_be",
            "fieldtype": "Select",
            "label": "Balance Must Be",
            "options": "\nDebit\nCredit"
        },
        {
            "fieldname": "tree_fields_section",
            "fieldtype": "Section Break",
            "label": "Tree Fields",
            "hidden": 1
        },
        {
            "fieldname": "lft",
            "fieldtype": "Int",
            "label": "Left",
            "hidden": 1,
            "search_index": 1
        },
        {
            "fieldname": "rgt",
            "fieldtype": "Int",
            "label": "Right",
            "hidden": 1,
            "search_index": 1
        },
        {
            "fieldname": "old_parent",
            "fieldtype": "Link",
            "label": "Old Parent",
            "options": "Account",
            "hidden": 1
        }
    ],
    "permissions": [
        {
            "role": "System Manager",
            "read": 1,
            "write": 1,
            "create": 1,
            "delete": 1,
            "export": 1,
            "import": 1
        },
        {
            "role": "Accounts Manager",
            "read": 1,
            "write": 1,
            "create": 1,
            "delete": 1,
            "export": 1
        },
        {
            "role": "Accounts User",
            "read": 1,
            "export": 1
        }
    ]
}
```

**Tree DocType Requirements:**

- `is_tree: 1` enables tree structure
- `nsm_parent_field`: specifies the parent link field (Nested Set Model)
- Required hidden fields: `lft`, `rgt` (for nested set), `old_parent` (for change tracking)
- `is_group`: indicates if node can have children
- `sort_field: "lft"` maintains tree order

---

*For Python controllers and app structure, see `08-python-controllers-app-structure.md`*
*For workspaces, export commands, and development workflow, see `09-workspaces-workflow-export.md`*
