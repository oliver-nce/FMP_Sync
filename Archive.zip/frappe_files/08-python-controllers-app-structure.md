# Python Controllers and App Structure

This document covers Python code structure, controllers, and app file organization for Frappe applications. For DocType JSON schema, see `07-doctype-json-reference.md`.

## 1. App Directory Structure

A complete Frappe app follows this structure:

```
apps/
└── my_app/
    ├── setup.py                      # Python package setup
    ├── requirements.txt              # Python dependencies
    ├── package.json                  # Node.js dependencies (optional)
    ├── license.txt                   # License file
    ├── MANIFEST.in                   # Include non-Python files
    ├── my_app/
    │   ├── __init__.py              # App version
    │   ├── hooks.py                  # App configuration
    │   ├── patches.txt               # Database migration patches
    │   ├── modules.txt               # List of modules
    │   │
    │   ├── my_module/               # Module directory
    │   │   ├── __init__.py
    │   │   │
    │   │   ├── doctype/             # DocTypes
    │   │   │   └── customer/
    │   │   │       ├── customer.json
    │   │   │       ├── customer.py
    │   │   │       ├── customer.js
    │   │   │       └── test_customer.py
    │   │   │
    │   │   ├── report/              # Reports
    │   │   │   └── sales_report/
    │   │   │       ├── sales_report.json
    │   │   │       ├── sales_report.py
    │   │   │       └── sales_report.js
    │   │   │
    │   │   ├── page/                # Custom pages
    │   │   │   └── dashboard/
    │   │   │       ├── dashboard.json
    │   │   │       ├── dashboard.py
    │   │   │       └── dashboard.js
    │   │   │
    │   │   └── workspace/           # Workspaces
    │   │       └── my_workspace.json
    │   │
    │   ├── public/                   # Public assets
    │   │   ├── js/
    │   │   │   └── my_app.js
    │   │   ├── css/
    │   │   │   └── my_app.css
    │   │   └── images/
    │   │
    │   ├── templates/                # Jinja templates
    │   │   ├── includes/
    │   │   └── pages/
    │   │
    │   ├── config/                   # Configuration files
    │   │   ├── __init__.py
    │   │   ├── desktop.py
    │   │   └── docs.py
    │   │
    │   └── api/                      # API modules (optional)
    │       ├── __init__.py
    │       └── customer_api.py
    │
    └── .git/                         # Git repository
```

### Key Directories Explained

| Directory | Purpose |
|-----------|---------|
| `doctype/` | DocType definitions (JSON + Python + JS) |
| `report/` | Script Reports and Query Reports |
| `page/` | Custom single pages |
| `workspace/` | Workspace JSON definitions |
| `public/` | Static assets served at `/assets/app_name/` |
| `templates/` | Jinja2 templates for web pages and emails |
| `config/` | App configuration (desktop icons, docs) |

---

## 2. Controller Basics

### Base Document Class

Every DocType controller inherits from `frappe.model.document.Document`:

```python
# my_app/my_module/doctype/customer/customer.py

import frappe
from frappe.model.document import Document

class Customer(Document):
    pass
```

### File Location

The controller file must be:
- In the same folder as the JSON: `doctype/customer/customer.py`
- Named exactly like the DocType (lowercase, underscores): `customer.py`
- Class named in PascalCase matching DocType: `class Customer`

### Controller Class Naming

| DocType Name | File Name | Class Name |
|--------------|-----------|------------|
| `Customer` | `customer.py` | `Customer` |
| `Sales Order` | `sales_order.py` | `SalesOrder` |
| `GL Entry` | `gl_entry.py` | `GlEntry` |
| `My Custom Doc` | `my_custom_doc.py` | `MyCustomDoc` |

### Essential Imports

```python
import frappe
from frappe import _                           # For translations
from frappe.model.document import Document
from frappe.utils import (
    nowdate, nowtime, now_datetime,            # Date/time
    flt, cint, cstr,                           # Type conversion
    getdate, get_datetime, add_days,           # Date manipulation
    format_date, format_datetime,              # Formatting
    validate_email_address                      # Validation
)
```

---

## 3. Lifecycle Hooks - Complete Reference

### validate()

**Signature:** `def validate(self):`

**When called:** Before every save (insert or update), before `before_save()`

**Use cases:**
- Data validation and business rules
- Calculated field updates
- Cross-field validation
- Data normalization

**Example:**

```python
def validate(self):
    self.validate_dates()
    self.validate_email()
    self.calculate_totals()
    self.set_title()

def validate_dates(self):
    if self.end_date and self.start_date:
        if getdate(self.end_date) < getdate(self.start_date):
            frappe.throw(_("End Date cannot be before Start Date"))

def validate_email(self):
    if self.email and not validate_email_address(self.email):
        frappe.throw(_("Invalid email address: {0}").format(self.email))

def calculate_totals(self):
    self.total_qty = sum(item.qty for item in self.items)
    self.grand_total = sum(flt(item.amount) for item in self.items)

def set_title(self):
    self.title = f"{self.customer_name} - {self.posting_date}"
```

**Gotchas:**
- Don't call `self.save()` inside validate (infinite loop)
- Use `frappe.throw()` for validation errors
- Runs for both new and existing documents

---

### before_save()

**Signature:** `def before_save(self):`

**When called:** After `validate()`, before database write

**Use cases:**
- Final modifications before save
- Setting computed values
- Auto-assignment logic

**Example:**

```python
def before_save(self):
    if not self.assigned_to and self.status == "Open":
        self.assigned_to = self.get_default_assignee()
    
    # Set modified tracking
    self.last_updated_by = frappe.session.user
```

---

### before_insert()

**Signature:** `def before_insert(self):`

**When called:** Before inserting a new document (before `validate()` for new docs)

**Use cases:**
- Set defaults for new documents
- Generate unique identifiers
- Initial setup logic

**Example:**

```python
def before_insert(self):
    self.status = "Draft"
    self.created_by = frappe.session.user
    
    if not self.priority:
        self.priority = "Medium"
```

---

### after_insert()

**Signature:** `def after_insert(self):`

**When called:** After document is inserted into database

**Use cases:**
- Send notifications
- Create related documents
- Log creation events

**Example:**

```python
def after_insert(self):
    self.send_welcome_email()
    self.create_default_address()
    frappe.publish_realtime("customer_created", {"name": self.name})

def send_welcome_email(self):
    if self.email:
        frappe.sendmail(
            recipients=[self.email],
            subject=_("Welcome to Our Platform"),
            template="welcome_customer",
            args={"customer_name": self.customer_name}
        )
```

---

### on_update()

**Signature:** `def on_update(self):`

**When called:** After document is saved (both insert and update)

**Use cases:**
- Update related documents
- Clear caches
- Sync external systems
- Audit logging

**Example:**

```python
def on_update(self):
    self.update_customer_group_count()
    self.sync_to_external_crm()
    frappe.clear_cache(doctype="Customer")

def update_customer_group_count(self):
    if self.has_value_changed("customer_group"):
        # Update count in Customer Group
        frappe.db.sql("""
            UPDATE `tabCustomer Group` cg
            SET cg.customer_count = (
                SELECT COUNT(*) FROM `tabCustomer` c 
                WHERE c.customer_group = cg.name
            )
            WHERE cg.name IN (%s, %s)
        """, (self.customer_group, self._doc_before_save.customer_group if self._doc_before_save else None))
```

---

### on_update_after_submit()

**Signature:** `def on_update_after_submit(self):`

**When called:** After a submitted document is updated (for `allow_on_submit` fields)

**Use cases:**
- Track post-submission changes
- Update linked submitted documents
- Recalculate dependent values

**Example:**

```python
def on_update_after_submit(self):
    if self.has_value_changed("delivery_date"):
        self.notify_delivery_date_change()
        self.update_production_schedule()
```

---

### before_submit()

**Signature:** `def before_submit(self):`

**When called:** Before document submission (docstatus: 0 → 1)

**Use cases:**
- Final validation before submission
- Set submission-time values
- Lock related documents

**Example:**

```python
def before_submit(self):
    self.validate_items_available()
    self.submission_date = nowdate()
    self.submitted_by = frappe.session.user

def validate_items_available(self):
    for item in self.items:
        available_qty = frappe.db.get_value("Item", item.item_code, "stock_qty")
        if flt(available_qty) < flt(item.qty):
            frappe.throw(_("Item {0}: Required {1}, Available {2}").format(
                item.item_code, item.qty, available_qty
            ))
```

---

### on_submit()

**Signature:** `def on_submit(self):`

**When called:** After document is submitted

**Use cases:**
- Create GL entries
- Update stock
- Create linked documents
- Send approval notifications

**Example:**

```python
def on_submit(self):
    self.create_gl_entries()
    self.update_stock_ledger()
    self.notify_approvers()

def create_gl_entries(self):
    from my_app.accounts.general_ledger import make_gl_entries
    
    gl_entries = []
    gl_entries.append({
        "account": self.debit_account,
        "debit": self.grand_total,
        "credit": 0
    })
    gl_entries.append({
        "account": self.credit_account,
        "debit": 0,
        "credit": self.grand_total
    })
    
    make_gl_entries(gl_entries, cancel=False, voucher_type=self.doctype, voucher_no=self.name)
```

---

### before_cancel()

**Signature:** `def before_cancel(self):`

**When called:** Before document cancellation (docstatus: 1 → 2)

**Use cases:**
- Validate cancellation is allowed
- Check linked documents
- Prevent cancellation in certain states

**Example:**

```python
def before_cancel(self):
    self.check_linked_documents()
    self.validate_cancellation_allowed()

def check_linked_documents(self):
    linked_invoices = frappe.get_all("Sales Invoice",
        filters={"sales_order": self.name, "docstatus": 1},
        pluck="name"
    )
    if linked_invoices:
        frappe.throw(_("Cannot cancel. Linked invoices exist: {0}").format(
            ", ".join(linked_invoices)
        ))
```

---

### on_cancel()

**Signature:** `def on_cancel(self):`

**When called:** After document is cancelled

**Use cases:**
- Reverse GL entries
- Restore stock
- Update linked documents
- Send cancellation notifications

**Example:**

```python
def on_cancel(self):
    self.reverse_gl_entries()
    self.restore_stock()
    self.update_linked_documents_status()

def reverse_gl_entries(self):
    from my_app.accounts.general_ledger import make_gl_entries
    make_gl_entries([], cancel=True, voucher_type=self.doctype, voucher_no=self.name)
```

---

### before_delete() / on_trash()

**Signature:** `def on_trash(self):`

**When called:** Before document deletion

**Use cases:**
- Clean up related data
- Validate deletion is allowed
- Archive data before deletion

**Example:**

```python
def on_trash(self):
    self.delete_related_communications()
    self.archive_to_history()

def delete_related_communications(self):
    frappe.db.delete("Communication", {
        "reference_doctype": self.doctype,
        "reference_name": self.name
    })
```

---

### after_delete()

**Signature:** `def after_delete(self):`

**When called:** After document is deleted from database

**Use cases:**
- Clear caches
- Log deletion
- Notify external systems

**Example:**

```python
def after_delete(self):
    frappe.log_error(
        title="Customer Deleted",
        message=f"Customer {self.name} deleted by {frappe.session.user}"
    )
    frappe.clear_cache(doctype="Customer")
```

---

### before_rename() / after_rename()

**Signature:** `def after_rename(self, old_name, new_name, merge):`

**When called:** After document is renamed

**Use cases:**
- Update references in other documents
- Rename related files
- Log rename action

**Example:**

```python
def after_rename(self, old_name, new_name, merge=False):
    # Update references in linked documents
    frappe.db.sql("""
        UPDATE `tabSales Order`
        SET customer = %s
        WHERE customer = %s
    """, (new_name, old_name))
```

---

## 4. Common Patterns

### Field Validation

```python
def validate(self):
    # Required field check
    if not self.customer_name:
        frappe.throw(_("Customer Name is required"))
    
    # Conditional required
    if self.is_company and not self.company_name:
        frappe.throw(_("Company Name is required when 'Is Company' is checked"))
    
    # Range validation
    if flt(self.discount_percent) < 0 or flt(self.discount_percent) > 100:
        frappe.throw(_("Discount must be between 0 and 100"))
    
    # Format validation
    if self.phone and not self.phone.replace("-", "").replace(" ", "").isdigit():
        frappe.throw(_("Invalid phone number format"))
```

### Calculated Fields

```python
def validate(self):
    self.calculate_item_amounts()
    self.calculate_totals()

def calculate_item_amounts(self):
    for item in self.items:
        item.amount = flt(item.qty) * flt(item.rate)
        
        if self.apply_discount:
            discount = flt(item.amount) * flt(self.discount_percent) / 100
            item.amount = flt(item.amount) - discount

def calculate_totals(self):
    self.total_qty = sum(flt(item.qty) for item in self.items)
    self.net_total = sum(flt(item.amount) for item in self.items)
    
    if self.apply_tax:
        self.tax_amount = flt(self.net_total) * flt(self.tax_rate) / 100
    else:
        self.tax_amount = 0
    
    self.grand_total = flt(self.net_total) + flt(self.tax_amount)
```

### Child Table Operations

```python
def validate(self):
    # Iterate child table
    for idx, item in enumerate(self.items, 1):
        item.idx = idx
        self.validate_item(item)
    
    # Check for duplicates
    items_seen = set()
    for item in self.items:
        if item.item_code in items_seen:
            frappe.throw(_("Duplicate item: {0}").format(item.item_code))
        items_seen.add(item.item_code)

def add_item(self, item_code, qty=1):
    """Programmatically add item to child table"""
    item_data = frappe.db.get_value("Item", item_code, 
        ["item_name", "standard_rate"], as_dict=True)
    
    self.append("items", {
        "item_code": item_code,
        "item_name": item_data.item_name,
        "qty": qty,
        "rate": item_data.standard_rate
    })

def remove_zero_qty_items(self):
    """Remove items with zero quantity"""
    self.items = [item for item in self.items if flt(item.qty) > 0]
```

### Database Queries

```python
# Get single value
customer_name = frappe.db.get_value("Customer", self.customer, "customer_name")

# Get multiple values
customer = frappe.db.get_value("Customer", self.customer, 
    ["customer_name", "email", "phone"], as_dict=True)

# Get list with filters
open_orders = frappe.db.get_all("Sales Order",
    filters={"customer": self.customer, "status": "Open"},
    fields=["name", "grand_total", "delivery_date"],
    order_by="delivery_date asc",
    limit=10
)

# Check existence
if frappe.db.exists("Customer", self.customer):
    pass

# Count records
order_count = frappe.db.count("Sales Order", {"customer": self.customer})

# Raw SQL (use sparingly)
result = frappe.db.sql("""
    SELECT item_code, SUM(qty) as total_qty
    FROM `tabSales Order Item`
    WHERE parent IN (
        SELECT name FROM `tabSales Order`
        WHERE customer = %s AND docstatus = 1
    )
    GROUP BY item_code
""", (self.customer,), as_dict=True)

# Set value directly (bypasses controller)
frappe.db.set_value("Customer", self.customer, "last_order_date", nowdate())
```

### Calling Other DocTypes

```python
# Get full document
customer = frappe.get_doc("Customer", self.customer)
print(customer.customer_name)

# Create new document
new_task = frappe.get_doc({
    "doctype": "Task",
    "subject": f"Follow up with {self.customer_name}",
    "reference_type": "Customer",
    "reference_name": self.name
})
new_task.insert()

# Update existing document
customer = frappe.get_doc("Customer", self.customer)
customer.last_contact_date = nowdate()
customer.save()

# Create from template
invoice = frappe.copy_doc(template_invoice)
invoice.customer = self.customer
invoice.insert()
```

---

## 5. Whitelisted Methods

### Basic Whitelist

```python
# my_app/my_module/doctype/customer/customer.py

import frappe

@frappe.whitelist()
def get_customer_orders(customer):
    """Get all orders for a customer"""
    if not customer:
        frappe.throw(_("Customer is required"))
    
    orders = frappe.get_all("Sales Order",
        filters={"customer": customer, "docstatus": 1},
        fields=["name", "grand_total", "status", "transaction_date"],
        order_by="transaction_date desc"
    )
    
    return orders
```

### Calling from Frontend

```javascript
// In customer.js or any client script
frappe.call({
    method: "my_app.my_module.doctype.customer.customer.get_customer_orders",
    args: {
        customer: frm.doc.name
    },
    callback: function(r) {
        if (r.message) {
            console.log(r.message);
        }
    }
});
```

### Document Method Whitelist

```python
class Customer(Document):
    @frappe.whitelist()
    def send_statement(self):
        """Send account statement to customer"""
        if not self.email:
            frappe.throw(_("Customer email is required"))
        
        statement = self.generate_statement()
        frappe.sendmail(
            recipients=[self.email],
            subject=_("Your Account Statement"),
            message=statement
        )
        
        return {"status": "sent", "email": self.email}
```

```javascript
// Call document method from JS
frm.call({
    method: "send_statement",
    doc: frm.doc,
    callback: function(r) {
        if (r.message.status === "sent") {
            frappe.show_alert(__("Statement sent to {0}", [r.message.email]));
        }
    }
});
```

### Permission Control

```python
@frappe.whitelist()
def admin_only_function():
    """Only System Manager can call this"""
    if "System Manager" not in frappe.get_roles():
        frappe.throw(_("Not permitted"), frappe.PermissionError)
    
    # ... function logic

@frappe.whitelist(allow_guest=True)
def public_function():
    """Anyone can call this, even guests"""
    return {"status": "ok"}
```

### Return Values

```python
@frappe.whitelist()
def process_data(data):
    # Return dict
    return {"success": True, "processed": 10}
    
    # Return list
    return [{"name": "Item 1"}, {"name": "Item 2"}]
    
    # Return simple value
    return "Processing complete"
    
    # Frappe wraps return value in {"message": <return_value>}
```

---

## 6. hooks.py Configuration

### Complete hooks.py Example

```python
# my_app/hooks.py

app_name = "my_app"
app_title = "My Application"
app_publisher = "My Company"
app_description = "Custom Frappe Application"
app_email = "support@mycompany.com"
app_license = "MIT"
app_version = "1.0.0"

# Required Frappe version
required_apps = ["frappe"]

# Include JS/CSS in all pages
app_include_css = "/assets/my_app/css/my_app.css"
app_include_js = "/assets/my_app/js/my_app.js"

# Include JS/CSS in web pages only
web_include_css = "/assets/my_app/css/my_app_web.css"
web_include_js = "/assets/my_app/js/my_app_web.js"

# Include JS in desk (app) pages only
# app_include_js = "/assets/my_app/js/my_app.bundle.js"

# Document Events
doc_events = {
    "Sales Invoice": {
        "validate": "my_app.events.sales_invoice.validate",
        "on_submit": "my_app.events.sales_invoice.on_submit",
        "on_cancel": "my_app.events.sales_invoice.on_cancel"
    },
    "Customer": {
        "after_insert": "my_app.events.customer.after_insert",
        "on_update": "my_app.events.customer.on_update"
    },
    "*": {
        # Apply to all DocTypes
        "on_update": "my_app.events.all_docs.log_changes"
    }
}

# Scheduled Tasks
scheduler_events = {
    "cron": {
        # Run at 6 AM daily
        "0 6 * * *": [
            "my_app.tasks.daily_report.send_daily_report"
        ],
        # Run every hour
        "0 * * * *": [
            "my_app.tasks.sync.sync_external_data"
        ]
    },
    "daily": [
        "my_app.tasks.cleanup.cleanup_old_records"
    ],
    "hourly": [
        "my_app.tasks.notifications.send_reminders"
    ],
    "weekly": [
        "my_app.tasks.reports.send_weekly_summary"
    ],
    "monthly": [
        "my_app.tasks.archive.archive_old_data"
    ]
}

# Override Whitelisted Methods
override_whitelisted_methods = {
    "frappe.desk.search.search_link": "my_app.overrides.custom_search_link"
}

# Override DocType Class
override_doctype_class = {
    "Sales Invoice": "my_app.overrides.sales_invoice.CustomSalesInvoice"
}

# Jinja Environment
jenv = {
    "methods": [
        "my_app.utils.jinja_methods.get_company_logo",
        "my_app.utils.jinja_methods.format_currency_words"
    ],
    "filters": [
        "my_app.utils.jinja_filters.highlight_text"
    ]
}

# Fixtures (auto-export)
fixtures = [
    "Custom Field",
    "Property Setter",
    {
        "doctype": "Role",
        "filters": [["name", "in", ["My Custom Role", "My Other Role"]]]
    },
    {
        "doctype": "Workflow",
        "filters": [["document_type", "=", "Purchase Order"]]
    }
]

# Installation Hooks
after_install = "my_app.setup.install.after_install"
before_uninstall = "my_app.setup.install.before_uninstall"
after_migrate = "my_app.setup.migrate.after_migrate"

# Boot Session (add data to client on page load)
boot_session = "my_app.startup.boot.boot_session"

# Permission Query Conditions
permission_query_conditions = {
    "Task": "my_app.permissions.task.get_permission_query_conditions"
}

# Has Permission
has_permission = {
    "Task": "my_app.permissions.task.has_permission"
}

# Website
website_route_rules = [
    {"from_route": "/products/<path>", "to_route": "products"}
]

# Website Generators
website_generators = ["Blog Post", "Web Page"]

# Home Page
home_page = "home"

# Portal Menu Items
portal_menu_items = [
    {"title": "My Orders", "route": "/orders", "role": "Customer"}
]
```

### Document Event Handler

```python
# my_app/events/sales_invoice.py

import frappe
from frappe import _

def validate(doc, method):
    """Called during Sales Invoice validation"""
    validate_customer_credit_limit(doc)

def on_submit(doc, method):
    """Called after Sales Invoice submission"""
    update_customer_balance(doc)
    send_invoice_email(doc)

def on_cancel(doc, method):
    """Called after Sales Invoice cancellation"""
    reverse_customer_balance(doc)

def validate_customer_credit_limit(doc):
    customer = frappe.get_doc("Customer", doc.customer)
    if customer.credit_limit and doc.grand_total > customer.credit_limit:
        frappe.throw(_("Invoice amount exceeds credit limit"))
```

### Boot Session

```python
# my_app/startup/boot.py

import frappe

def boot_session(bootinfo):
    """Add custom data to boot info sent to client"""
    bootinfo.my_app_settings = {
        "enable_feature_x": frappe.db.get_single_value("My Settings", "enable_feature_x"),
        "default_warehouse": frappe.db.get_single_value("My Settings", "default_warehouse")
    }
    
    # Add user-specific data
    if frappe.session.user != "Guest":
        bootinfo.user_warehouses = frappe.get_all("User Warehouse",
            filters={"user": frappe.session.user},
            pluck="warehouse"
        )
```

---

## 7. modules.txt & setup.py

### modules.txt

List each module on a separate line:

```
My Module
Accounts
Inventory
Reports
```

This file tells Frappe which modules exist in your app.

### setup.py

```python
from setuptools import setup, find_packages

with open("requirements.txt") as f:
    install_requires = f.read().strip().split("\n")

setup(
    name="my_app",
    version="1.0.0",
    description="My Custom Frappe Application",
    author="My Company",
    author_email="support@mycompany.com",
    packages=find_packages(),
    zip_safe=False,
    include_package_data=True,
    install_requires=install_requires
)
```

### requirements.txt

```
# Python dependencies
frappe
requests>=2.25.0
pandas>=1.3.0
```

### __init__.py

```python
# my_app/__init__.py

__version__ = "1.0.0"
```

---

## 8. Complete Working Example

### Customer Management App

**File: customer/customer.py**

```python
"""
Customer DocType Controller

Handles customer lifecycle, validation, and business logic.
For JSON schema, see customer.json
"""

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import nowdate, flt, cint, validate_email_address, getdate, add_days


class Customer(Document):
    """
    Customer document controller.
    
    Handles:
    - Customer data validation
    - Credit limit management
    - Address management
    - Order statistics
    """
    
    # ============================================================
    # LIFECYCLE HOOKS
    # ============================================================
    
    def before_insert(self):
        """Set defaults for new customers"""
        if not self.status:
            self.status = "Active"
        
        if not self.customer_type:
            self.customer_type = "Individual"
        
        # Generate customer code if not provided
        if not self.customer_code:
            self.customer_code = self.generate_customer_code()
    
    def validate(self):
        """Validate customer data before save"""
        self.validate_email()
        self.validate_phone()
        self.validate_credit_limit()
        self.calculate_statistics()
        self.set_full_name()
    
    def before_save(self):
        """Final modifications before save"""
        # Update status based on conditions
        if self.outstanding_amount > flt(self.credit_limit) and self.credit_limit:
            self.status = "Credit Hold"
        
        # Set territory from address if not set
        if not self.territory and self.addresses:
            primary_address = next(
                (a for a in self.addresses if a.is_primary), 
                self.addresses[0] if self.addresses else None
            )
            if primary_address:
                self.territory = primary_address.state
    
    def after_insert(self):
        """Actions after customer creation"""
        self.send_welcome_notification()
        
        # Create default address if provided during creation
        if self.default_address_line1:
            self.create_default_address()
    
    def on_update(self):
        """Actions after customer save"""
        # Clear cache
        frappe.clear_cache(doctype="Customer")
        
        # Update linked documents if name changed
        if self.has_value_changed("customer_name"):
            self.update_linked_documents()
    
    def on_trash(self):
        """Validation and cleanup before deletion"""
        # Check for linked transactions
        self.validate_no_linked_transactions()
        
        # Delete related records
        self.delete_addresses()
        self.delete_communications()
    
    # ============================================================
    # VALIDATION METHODS
    # ============================================================
    
    def validate_email(self):
        """Validate email format"""
        if self.email:
            if not validate_email_address(self.email):
                frappe.throw(
                    _("Invalid email address: {0}").format(self.email),
                    title=_("Validation Error")
                )
            
            # Check for duplicate email
            existing = frappe.db.get_value("Customer", 
                {"email": self.email, "name": ("!=", self.name)}, "name")
            if existing:
                frappe.throw(
                    _("Email {0} already exists for customer {1}").format(
                        self.email, existing
                    )
                )
    
    def validate_phone(self):
        """Validate and format phone number"""
        if self.phone:
            # Remove non-numeric characters for validation
            digits = ''.join(filter(str.isdigit, self.phone))
            if len(digits) < 10:
                frappe.throw(_("Phone number must have at least 10 digits"))
    
    def validate_credit_limit(self):
        """Validate credit limit settings"""
        if flt(self.credit_limit) < 0:
            frappe.throw(_("Credit limit cannot be negative"))
        
        if self.credit_limit and flt(self.credit_limit) < flt(self.outstanding_amount):
            frappe.msgprint(
                _("Warning: Credit limit is less than outstanding amount"),
                indicator="orange",
                alert=True
            )
    
    def validate_no_linked_transactions(self):
        """Check for linked transactions before deletion"""
        # Check Sales Orders
        orders = frappe.db.count("Sales Order", {"customer": self.name, "docstatus": 1})
        if orders:
            frappe.throw(
                _("Cannot delete customer with {0} submitted Sales Orders").format(orders)
            )
        
        # Check Sales Invoices
        invoices = frappe.db.count("Sales Invoice", {"customer": self.name, "docstatus": 1})
        if invoices:
            frappe.throw(
                _("Cannot delete customer with {0} submitted Sales Invoices").format(invoices)
            )
    
    # ============================================================
    # CALCULATION METHODS
    # ============================================================
    
    def calculate_statistics(self):
        """Calculate customer statistics"""
        # Total orders
        self.total_orders = frappe.db.count("Sales Order", {
            "customer": self.name,
            "docstatus": 1
        })
        
        # Total order value
        total_value = frappe.db.sql("""
            SELECT COALESCE(SUM(grand_total), 0) 
            FROM `tabSales Order`
            WHERE customer = %s AND docstatus = 1
        """, self.name)[0][0]
        self.lifetime_value = flt(total_value, 2)
        
        # Last order date
        last_order = frappe.db.get_value("Sales Order",
            {"customer": self.name, "docstatus": 1},
            "transaction_date",
            order_by="transaction_date desc"
        )
        self.last_order_date = last_order
    
    def set_full_name(self):
        """Set full name from components"""
        if self.customer_type == "Individual":
            parts = [self.first_name, self.middle_name, self.last_name]
            self.customer_name = " ".join(p for p in parts if p)
        # For companies, customer_name is entered directly
    
    # ============================================================
    # HELPER METHODS
    # ============================================================
    
    def generate_customer_code(self):
        """Generate unique customer code"""
        prefix = "CUST"
        
        # Get last customer code
        last_code = frappe.db.sql("""
            SELECT customer_code 
            FROM `tabCustomer`
            WHERE customer_code LIKE %s
            ORDER BY customer_code DESC
            LIMIT 1
        """, f"{prefix}%")
        
        if last_code:
            last_num = int(last_code[0][0].replace(prefix, ""))
            new_num = last_num + 1
        else:
            new_num = 1
        
        return f"{prefix}{new_num:05d}"
    
    def send_welcome_notification(self):
        """Send welcome email to new customer"""
        if not self.email:
            return
        
        try:
            frappe.sendmail(
                recipients=[self.email],
                subject=_("Welcome, {0}!").format(self.customer_name),
                template="customer_welcome",
                args={
                    "customer_name": self.customer_name,
                    "customer_code": self.customer_code
                },
                delayed=True
            )
        except Exception as e:
            frappe.log_error(f"Failed to send welcome email: {e}")
    
    def create_default_address(self):
        """Create default address from inline fields"""
        address = frappe.get_doc({
            "doctype": "Address",
            "address_title": f"{self.customer_name} - Primary",
            "address_type": "Billing",
            "address_line1": self.default_address_line1,
            "city": self.default_city,
            "state": self.default_state,
            "country": self.default_country or "United States",
            "pincode": self.default_pincode,
            "links": [{
                "link_doctype": "Customer",
                "link_name": self.name
            }]
        })
        address.insert(ignore_permissions=True)
    
    def update_linked_documents(self):
        """Update customer name in linked documents"""
        # This is typically handled by rename, but useful for display fields
        pass
    
    def delete_addresses(self):
        """Delete addresses linked to this customer"""
        addresses = frappe.get_all("Dynamic Link",
            filters={
                "link_doctype": "Customer",
                "link_name": self.name,
                "parenttype": "Address"
            },
            pluck="parent"
        )
        for address in addresses:
            frappe.delete_doc("Address", address, ignore_permissions=True)
    
    def delete_communications(self):
        """Delete communications linked to this customer"""
        frappe.db.delete("Communication", {
            "reference_doctype": "Customer",
            "reference_name": self.name
        })
    
    # ============================================================
    # WHITELISTED METHODS (Callable from frontend)
    # ============================================================
    
    @frappe.whitelist()
    def get_order_summary(self):
        """
        Get order summary for this customer.
        
        Returns:
            dict: Order summary with counts and totals
        """
        summary = {
            "total_orders": 0,
            "pending_orders": 0,
            "total_value": 0,
            "pending_value": 0,
            "recent_orders": []
        }
        
        # Get counts
        summary["total_orders"] = frappe.db.count("Sales Order", {
            "customer": self.name,
            "docstatus": 1
        })
        
        summary["pending_orders"] = frappe.db.count("Sales Order", {
            "customer": self.name,
            "docstatus": 1,
            "status": ["in", ["Draft", "To Deliver", "To Bill"]]
        })
        
        # Get values
        totals = frappe.db.sql("""
            SELECT 
                COALESCE(SUM(grand_total), 0) as total_value,
                COALESCE(SUM(CASE WHEN status IN ('Draft', 'To Deliver', 'To Bill') 
                    THEN grand_total ELSE 0 END), 0) as pending_value
            FROM `tabSales Order`
            WHERE customer = %s AND docstatus = 1
        """, self.name, as_dict=True)[0]
        
        summary["total_value"] = flt(totals.total_value, 2)
        summary["pending_value"] = flt(totals.pending_value, 2)
        
        # Get recent orders
        summary["recent_orders"] = frappe.get_all("Sales Order",
            filters={"customer": self.name, "docstatus": 1},
            fields=["name", "transaction_date", "grand_total", "status"],
            order_by="transaction_date desc",
            limit=5
        )
        
        return summary
    
    @frappe.whitelist()
    def update_credit_limit(self, new_limit):
        """
        Update customer credit limit.
        
        Args:
            new_limit: New credit limit value
        
        Returns:
            dict: Status message
        """
        # Permission check
        if "Accounts Manager" not in frappe.get_roles():
            frappe.throw(_("Only Accounts Manager can update credit limit"))
        
        new_limit = flt(new_limit)
        if new_limit < 0:
            frappe.throw(_("Credit limit cannot be negative"))
        
        old_limit = self.credit_limit
        self.credit_limit = new_limit
        self.save()
        
        # Log the change
        frappe.log_error(
            title="Credit Limit Changed",
            message=f"Customer {self.name}: {old_limit} → {new_limit} by {frappe.session.user}"
        )
        
        return {
            "status": "success",
            "message": _("Credit limit updated to {0}").format(new_limit)
        }


# ============================================================
# STANDALONE WHITELISTED FUNCTIONS
# ============================================================

@frappe.whitelist()
def get_customer_list(territory=None, status=None):
    """
    Get filtered customer list.
    
    Args:
        territory: Filter by territory
        status: Filter by status
    
    Returns:
        list: List of customer records
    """
    filters = {}
    if territory:
        filters["territory"] = territory
    if status:
        filters["status"] = status
    
    return frappe.get_all("Customer",
        filters=filters,
        fields=["name", "customer_name", "customer_code", "email", "status", "territory"],
        order_by="customer_name asc",
        limit=100
    )


@frappe.whitelist()
def merge_customers(source_customer, target_customer):
    """
    Merge two customer records.
    
    Args:
        source_customer: Customer to merge from (will be deleted)
        target_customer: Customer to merge into
    
    Returns:
        dict: Merge status
    """
    # Permission check
    if "System Manager" not in frappe.get_roles():
        frappe.throw(_("Only System Manager can merge customers"))
    
    if source_customer == target_customer:
        frappe.throw(_("Cannot merge customer with itself"))
    
    # Update all references
    for doctype in ["Sales Order", "Sales Invoice", "Delivery Note", "Payment Entry"]:
        frappe.db.sql(f"""
            UPDATE `tab{doctype}`
            SET customer = %s
            WHERE customer = %s
        """, (target_customer, source_customer))
    
    # Delete source customer
    frappe.delete_doc("Customer", source_customer, force=True)
    
    return {
        "status": "success",
        "message": _("Customer {0} merged into {1}").format(source_customer, target_customer)
    }
```

---

*For DocType JSON schema, see `07-doctype-json-reference.md`*
*For workspaces, export commands, and development workflow, see `09-workspaces-workflow-export.md`*
