# Workspaces, Workflow, and Export

This document covers Workspace definitions, bench export commands, fixtures, and the complete development workflow for Frappe applications. For DocType JSON schema, see `07-doctype-json-reference.md`. For Python controllers, see `08-python-controllers-app-structure.md`.

## 1. Workspace JSON Structure

Workspaces define the navigation and dashboard experience in Frappe. They appear in the sidebar and can contain links, shortcuts, charts, and quick lists.

### Complete Schema

```json
{
    "name": "My Workspace",
    "doctype": "Workspace",
    "module": "My Module",
    "label": "My Workspace",
    "title": "My Workspace Dashboard",
    "icon": "tool",
    "indicator_color": "blue",
    "is_standard": 1,
    "public": 1,
    "category": "",
    "parent_page": "",
    "sequence_id": 10,
    "for_user": "",
    "restrict_to_domain": "",
    "hide_custom": 0,
    "extends_another_page": 0,
    "charts": [],
    "shortcuts": [],
    "links": [],
    "quick_lists": [],
    "number_cards": [],
    "custom_blocks": []
}
```

### Property Reference

| Property | Type | Description |
|----------|------|-------------|
| `name` | String | Unique workspace identifier |
| `module` | String | Module this workspace belongs to |
| `label` | String | Display label in sidebar |
| `title` | String | Page title (defaults to label) |
| `icon` | String | Icon name (Frappe icon set) |
| `indicator_color` | String | Color indicator: blue, green, red, orange, yellow, gray |
| `is_standard` | 0/1 | Part of standard app (vs custom) |
| `public` | 0/1 | Visible to all users |
| `category` | String | Grouping category in sidebar |
| `parent_page` | String | Parent workspace for nesting |
| `sequence_id` | Int | Sort order (lower = higher) |
| `for_user` | String | Restrict to specific user |
| `restrict_to_domain` | String | Restrict to domain |
| `hide_custom` | 0/1 | Hide custom additions |
| `extends_another_page` | 0/1 | Extends another workspace |

### Links Array

Links appear as cards/sections in the workspace:

```json
{
    "links": [
        {
            "type": "Card Break",
            "label": "Masters"
        },
        {
            "type": "Link",
            "label": "Customer",
            "link_to": "Customer",
            "link_type": "DocType",
            "onboard": 1,
            "is_query_report": 0,
            "only_for": ""
        },
        {
            "type": "Link",
            "label": "Supplier",
            "link_to": "Supplier",
            "link_type": "DocType"
        },
        {
            "type": "Card Break",
            "label": "Transactions"
        },
        {
            "type": "Link",
            "label": "Sales Order",
            "link_to": "Sales Order",
            "link_type": "DocType"
        },
        {
            "type": "Link",
            "label": "Sales Analytics",
            "link_to": "Sales Analytics",
            "link_type": "Report",
            "is_query_report": 1,
            "dependencies": "Sales Order"
        }
    ]
}
```

**Link Properties:**

| Property | Type | Description |
|----------|------|-------------|
| `type` | String | `"Link"` or `"Card Break"` |
| `label` | String | Display text |
| `link_to` | String | DocType/Report/Page name |
| `link_type` | String | `"DocType"`, `"Report"`, `"Page"` |
| `onboard` | 0/1 | Highlight for new users |
| `is_query_report` | 0/1 | Is this a Query Report |
| `only_for` | String | Restrict to role |
| `dependencies` | String | Required DocTypes |

### Shortcuts Array

Shortcuts appear at the top of the workspace:

```json
{
    "shortcuts": [
        {
            "type": "Shortcut",
            "label": "New Customer",
            "link_to": "Customer",
            "doc_view": "New",
            "color": "blue",
            "icon": "add"
        },
        {
            "type": "Shortcut",
            "label": "Open Orders",
            "link_to": "Sales Order",
            "doc_view": "List",
            "stats_filter": "{\"status\": \"Open\"}",
            "color": "orange"
        },
        {
            "type": "Shortcut",
            "label": "Monthly Sales",
            "link_to": "Sales Analytics",
            "doc_view": "Report",
            "is_query_report": 1,
            "color": "green"
        }
    ]
}
```

**Shortcut Properties:**

| Property | Type | Description |
|----------|------|-------------|
| `type` | String | Always `"Shortcut"` |
| `label` | String | Button text |
| `link_to` | String | Target DocType/Report |
| `doc_view` | String | `"New"`, `"List"`, `"Report"`, `"Tree"`, `"Kanban"` |
| `stats_filter` | String | JSON filter for count badge |
| `color` | String | blue, green, red, orange, yellow, gray, pink, cyan |
| `icon` | String | Icon name |
| `is_query_report` | 0/1 | Is Query Report |

### Charts Array

Dashboard charts:

```json
{
    "charts": [
        {
            "chart_name": "Sales Trend",
            "label": "Monthly Sales",
            "chart_type": "Line"
        },
        {
            "chart_name": "Order Status",
            "label": "Orders by Status",
            "chart_type": "Pie"
        }
    ]
}
```

Charts reference Dashboard Chart documents.

### Number Cards Array

KPI cards showing counts or sums:

```json
{
    "number_cards": [
        {
            "number_card_name": "Total Customers",
            "label": "Customers"
        },
        {
            "number_card_name": "Open Orders",
            "label": "Pending Orders"
        }
    ]
}
```

Number cards reference Number Card documents.

### Quick Lists Array

Embedded list views:

```json
{
    "quick_lists": [
        {
            "label": "Recent Orders",
            "document_type": "Sales Order",
            "filters": "{\"status\": [\"in\", [\"Open\", \"Pending\"]]}",
            "order_by": "creation desc",
            "limit": 5
        }
    ]
}
```

---

### Example 1: Simple Workspace (Links Only)

```json
{
    "name": "Inventory",
    "doctype": "Workspace",
    "module": "Inventory",
    "label": "Inventory",
    "icon": "stock",
    "indicator_color": "green",
    "is_standard": 1,
    "public": 1,
    "sequence_id": 15,
    "links": [
        {
            "type": "Card Break",
            "label": "Masters"
        },
        {
            "type": "Link",
            "label": "Item",
            "link_to": "Item",
            "link_type": "DocType",
            "onboard": 1
        },
        {
            "type": "Link",
            "label": "Item Group",
            "link_to": "Item Group",
            "link_type": "DocType"
        },
        {
            "type": "Link",
            "label": "Warehouse",
            "link_to": "Warehouse",
            "link_type": "DocType"
        },
        {
            "type": "Card Break",
            "label": "Transactions"
        },
        {
            "type": "Link",
            "label": "Stock Entry",
            "link_to": "Stock Entry",
            "link_type": "DocType"
        },
        {
            "type": "Link",
            "label": "Stock Reconciliation",
            "link_to": "Stock Reconciliation",
            "link_type": "DocType"
        },
        {
            "type": "Card Break",
            "label": "Reports"
        },
        {
            "type": "Link",
            "label": "Stock Balance",
            "link_to": "Stock Balance",
            "link_type": "Report",
            "is_query_report": 1
        },
        {
            "type": "Link",
            "label": "Stock Ledger",
            "link_to": "Stock Ledger",
            "link_type": "Report",
            "is_query_report": 1
        }
    ],
    "shortcuts": [],
    "charts": [],
    "number_cards": []
}
```

### Example 2: Complex Workspace (All Elements)

```json
{
    "name": "Sales",
    "doctype": "Workspace",
    "module": "Selling",
    "label": "Sales",
    "title": "Sales Dashboard",
    "icon": "sell",
    "indicator_color": "blue",
    "is_standard": 1,
    "public": 1,
    "sequence_id": 5,
    "shortcuts": [
        {
            "type": "Shortcut",
            "label": "New Quotation",
            "link_to": "Quotation",
            "doc_view": "New",
            "color": "blue",
            "icon": "add"
        },
        {
            "type": "Shortcut",
            "label": "New Sales Order",
            "link_to": "Sales Order",
            "doc_view": "New",
            "color": "green",
            "icon": "add"
        },
        {
            "type": "Shortcut",
            "label": "Draft Orders",
            "link_to": "Sales Order",
            "doc_view": "List",
            "stats_filter": "{\"docstatus\": 0}",
            "color": "orange"
        },
        {
            "type": "Shortcut",
            "label": "To Deliver",
            "link_to": "Sales Order",
            "doc_view": "List",
            "stats_filter": "{\"status\": \"To Deliver and Bill\"}",
            "color": "yellow"
        }
    ],
    "number_cards": [
        {
            "number_card_name": "Total Customers",
            "label": "Customers"
        },
        {
            "number_card_name": "This Month Sales",
            "label": "Monthly Revenue"
        },
        {
            "number_card_name": "Open Quotations",
            "label": "Pending Quotes"
        }
    ],
    "charts": [
        {
            "chart_name": "Sales Trend",
            "label": "Sales Trend (Last 12 Months)"
        },
        {
            "chart_name": "Top Customers",
            "label": "Top 10 Customers"
        }
    ],
    "quick_lists": [
        {
            "label": "Recent Quotations",
            "document_type": "Quotation",
            "filters": "{}",
            "order_by": "creation desc",
            "limit": 5
        }
    ],
    "links": [
        {
            "type": "Card Break",
            "label": "Customers"
        },
        {
            "type": "Link",
            "label": "Customer",
            "link_to": "Customer",
            "link_type": "DocType",
            "onboard": 1
        },
        {
            "type": "Link",
            "label": "Customer Group",
            "link_to": "Customer Group",
            "link_type": "DocType"
        },
        {
            "type": "Link",
            "label": "Territory",
            "link_to": "Territory",
            "link_type": "DocType"
        },
        {
            "type": "Card Break",
            "label": "Sales Transactions"
        },
        {
            "type": "Link",
            "label": "Quotation",
            "link_to": "Quotation",
            "link_type": "DocType",
            "onboard": 1
        },
        {
            "type": "Link",
            "label": "Sales Order",
            "link_to": "Sales Order",
            "link_type": "DocType",
            "onboard": 1
        },
        {
            "type": "Link",
            "label": "Sales Invoice",
            "link_to": "Sales Invoice",
            "link_type": "DocType"
        },
        {
            "type": "Card Break",
            "label": "Fulfillment"
        },
        {
            "type": "Link",
            "label": "Delivery Note",
            "link_to": "Delivery Note",
            "link_type": "DocType"
        },
        {
            "type": "Link",
            "label": "Packing Slip",
            "link_to": "Packing Slip",
            "link_type": "DocType"
        },
        {
            "type": "Card Break",
            "label": "Reports & Analytics"
        },
        {
            "type": "Link",
            "label": "Sales Analytics",
            "link_to": "Sales Analytics",
            "link_type": "Report",
            "is_query_report": 1
        },
        {
            "type": "Link",
            "label": "Sales Funnel",
            "link_to": "Sales Funnel",
            "link_type": "Report",
            "is_query_report": 1
        },
        {
            "type": "Link",
            "label": "Customer Acquisition",
            "link_to": "Customer Acquisition and Loyalty",
            "link_type": "Report",
            "is_query_report": 1
        },
        {
            "type": "Card Break",
            "label": "Settings"
        },
        {
            "type": "Link",
            "label": "Selling Settings",
            "link_to": "Selling Settings",
            "link_type": "DocType"
        },
        {
            "type": "Link",
            "label": "Sales Taxes and Charges Template",
            "link_to": "Sales Taxes and Charges Template",
            "link_type": "DocType"
        }
    ]
}
```

---

## 2. Export Commands

### Export Single DocType Definition

```bash
# Export DocType schema to JSON file
bench --site mysite.local export-doc "DocType" "Customer" > customer.json

# Export to specific path
bench --site mysite.local export-doc "DocType" "Customer" > ~/frappe-bench/apps/myapp/myapp/selling/doctype/customer/customer.json
```

### Export Workspace

```bash
# Export workspace definition
bench --site mysite.local export-doc "Workspace" "Sales" > sales_workspace.json

# Save to app workspace directory
bench --site mysite.local export-doc "Workspace" "Sales" > ~/frappe-bench/apps/myapp/myapp/selling/workspace/sales/sales.json
```

### Export Other Document Types

```bash
# Export Custom Field
bench --site mysite.local export-doc "Custom Field" "Customer-custom_field_name"

# Export Property Setter
bench --site mysite.local export-doc "Property Setter" "Customer-main-reqd"

# Export Report
bench --site mysite.local export-doc "Report" "Sales Analytics"

# Export Print Format
bench --site mysite.local export-doc "Print Format" "Sales Invoice Format"

# Export Workflow
bench --site mysite.local export-doc "Workflow" "Purchase Order Approval"

# Export Email Template
bench --site mysite.local export-doc "Email Template" "Customer Welcome"
```

### Batch Export Multiple Documents

```bash
# Export all Custom Fields for a DocType
bench --site mysite.local execute "frappe.core.doctype.data_export.exporter.export_data" --args '["Custom Field", "doctype", "Customer"]'

# Shell script for multiple exports
#!/bin/bash
SITE="mysite.local"
APP_PATH="$HOME/frappe-bench/apps/myapp"

# Export DocTypes
for doctype in "Customer" "Sales Order" "Sales Order Item"; do
    folder=$(echo "$doctype" | tr '[:upper:]' '[:lower:]' | tr ' ' '_')
    bench --site $SITE export-doc "DocType" "$doctype" > "$APP_PATH/myapp/selling/doctype/$folder/$folder.json"
done

# Export Workspaces
for workspace in "Sales" "Inventory"; do
    folder=$(echo "$workspace" | tr '[:upper:]' '[:lower:]' | tr ' ' '_')
    bench --site $SITE export-doc "Workspace" "$workspace" > "$APP_PATH/myapp/config/workspace/$folder/$folder.json"
done
```

### Clean Exported JSON

Exported JSON contains metadata that should be removed for version control:

**Fields to remove from exported JSON:**

```python
# Remove these fields from exported JSON:
remove_fields = [
    "modified",
    "modified_by", 
    "creation",
    "owner",
    "docstatus",
    "idx",
    "__last_sync_on",
    "__islocal",
    "__unsaved"
]
```

**Python script to clean JSON:**

```python
#!/usr/bin/env python3
"""
Clean exported Frappe JSON files for version control.
Usage: python clean_json.py customer.json
"""

import json
import sys

def clean_frappe_json(data):
    """Remove volatile fields from Frappe export"""
    remove_keys = {
        "modified", "modified_by", "creation", "owner", 
        "docstatus", "__last_sync_on", "__islocal", "__unsaved"
    }
    
    if isinstance(data, dict):
        # Remove top-level fields
        for key in remove_keys:
            data.pop(key, None)
        
        # Process nested structures
        for key, value in data.items():
            if isinstance(value, list):
                for item in value:
                    clean_frappe_json(item)
            elif isinstance(value, dict):
                clean_frappe_json(value)
    
    return data

if __name__ == "__main__":
    filepath = sys.argv[1]
    
    with open(filepath, 'r') as f:
        data = json.load(f)
    
    cleaned = clean_frappe_json(data)
    
    with open(filepath, 'w') as f:
        json.dump(cleaned, f, indent=1, sort_keys=True)
    
    print(f"Cleaned: {filepath}")
```

**Bash one-liner using jq:**

```bash
# Clean JSON with jq (remove volatile fields)
jq 'del(.modified, .modified_by, .creation, .owner, .docstatus) | 
    if .fields then .fields |= map(del(.modified, .modified_by, .creation, .owner)) else . end |
    if .permissions then .permissions |= map(del(.modified, .modified_by, .creation, .owner)) else . end' \
    customer.json > customer_clean.json
```

---

## 3. Fixtures

Fixtures automatically export and import specific document types when you install or update your app.

### What Are Fixtures?

Fixtures are document records that should be included with your app. They're used for:

- Custom Fields added by your app
- Property Setters (field modifications)
- Custom Roles
- Workflows
- Print Formats
- Email Templates
- Dashboard Charts
- Number Cards

### Configure Fixtures in hooks.py

```python
# hooks.py

fixtures = [
    # Export all records of these DocTypes
    "Custom Field",
    "Property Setter",
    
    # Export with filters
    {
        "doctype": "Role",
        "filters": [
            ["name", "in", ["Inventory Manager", "Warehouse User"]]
        ]
    },
    
    # Export workflows for specific documents
    {
        "doctype": "Workflow",
        "filters": [
            ["document_type", "in", ["Purchase Order", "Sales Order"]]
        ]
    },
    
    # Export custom print formats
    {
        "doctype": "Print Format",
        "filters": [
            ["module", "=", "My Module"]
        ]
    },
    
    # Export dashboard elements
    {
        "doctype": "Dashboard Chart",
        "filters": [
            ["module", "=", "My Module"]
        ]
    },
    {
        "doctype": "Number Card",
        "filters": [
            ["module", "=", "My Module"]
        ]
    }
]
```

### Export Fixtures Command

```bash
# Export all fixtures defined in hooks.py
bench --site mysite.local export-fixtures

# This creates JSON files in:
# apps/myapp/myapp/fixtures/
```

### Fixture File Structure

```
apps/myapp/myapp/
├── fixtures/
│   ├── custom_field.json
│   ├── property_setter.json
│   ├── role.json
│   ├── workflow.json
│   └── print_format.json
```

### When Fixtures Are Imported

Fixtures are automatically imported during:

- `bench --site mysite install-app myapp`
- `bench --site mysite migrate`

### Manual Fixture Import

```bash
# Import fixtures manually
bench --site mysite.local import-fixtures

# Import from specific app
bench --site mysite.local import-fixtures --app myapp
```

### Fixture Best Practices

1. **Only fixture what's necessary** - Don't fixture sample data
2. **Use filters** - Don't export all Custom Fields, only yours
3. **Clean before export** - Remove test/temporary records
4. **Test imports** - Verify fixtures work on fresh install
5. **Order matters** - Roles before Workflows (dependencies)

---

## 4. Development Workflow

### Initial Setup: Create New App

```bash
# Navigate to bench directory
cd ~/frappe-bench

# Create new app
bench new-app myapp
# Follow prompts for app name, title, publisher, etc.

# Install app on development site
bench --site mysite.local install-app myapp

# Initialize git repository
cd apps/myapp
git init
git add .
git commit -m "Initial commit: App scaffold"

# Create GitHub repository (via web or CLI)
# Then push
git remote add origin https://github.com/username/myapp.git
git branch -M main
git push -u origin main
```

### Create App Structure

```bash
cd ~/frappe-bench/apps/myapp/myapp

# Create module
mkdir -p selling/doctype
mkdir -p selling/report
mkdir -p selling/workspace

# Add module to modules.txt
echo "Selling" >> modules.txt
```

### Adding New DocType

**Step 1: Create DocType folder and files**

```bash
cd ~/frappe-bench/apps/myapp/myapp/selling/doctype
mkdir customer
touch customer/customer.json
touch customer/customer.py
touch customer/__init__.py
```

**Step 2: Create JSON definition**

Create `customer.json` following the schema in `07-doctype-json-reference.md`.

**Step 3: Create Python controller**

Create `customer.py` following the patterns in `08-python-controllers-app-structure.md`.

**Step 4: Commit and push**

```bash
cd ~/frappe-bench/apps/myapp
git add .
git commit -m "feat: Add Customer DocType"
git push origin main
```

**Step 5: On server - Pull and migrate**

```bash
cd ~/frappe-bench/apps/myapp
git pull origin main

# Apply changes
bench --site production.local migrate

# Clear cache
bench --site production.local clear-cache

# Restart (if needed)
bench restart
```

### Updating Existing DocType

**Step 1: Edit JSON locally**

Modify the `.json` file with new fields, permissions, etc.

**Step 2: Test locally**

```bash
# Apply migration
bench --site mysite.local migrate

# Clear cache
bench --site mysite.local clear-cache

# Verify changes in browser
```

**Step 3: Update Python controller if needed**

Add validation, calculations, etc.

**Step 4: Commit and push**

```bash
cd ~/frappe-bench/apps/myapp
git add .
git commit -m "feat: Add credit_limit field to Customer"
git push origin main
```

**Step 5: Deploy to server**

```bash
# On production server
cd ~/frappe-bench/apps/myapp
git pull origin main
bench --site production.local migrate
bench --site production.local clear-cache
bench restart
```

### Complete Development Cycle

```
┌─────────────────────────────────────────────────────────────┐
│                     LOCAL DEVELOPMENT                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. Edit JSON/Python files                                  │
│     └── apps/myapp/myapp/module/doctype/name/              │
│                                                             │
│  2. Apply changes locally                                   │
│     └── bench --site devsite migrate                       │
│     └── bench --site devsite clear-cache                   │
│                                                             │
│  3. Test in browser                                         │
│     └── http://devsite:8000                                │
│                                                             │
│  4. Export if created via UI                               │
│     └── bench --site devsite export-doc "DocType" "Name"   │
│                                                             │
│  5. Git commit                                              │
│     └── git add . && git commit -m "message"               │
│                                                             │
│  6. Push to repository                                      │
│     └── git push origin main                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     PRODUCTION SERVER                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. Pull latest code                                        │
│     └── cd apps/myapp && git pull origin main              │
│                                                             │
│  2. Run migrations                                          │
│     └── bench --site prodsite migrate                      │
│                                                             │
│  3. Clear cache                                             │
│     └── bench --site prodsite clear-cache                  │
│                                                             │
│  4. Restart services (if needed)                           │
│     └── bench restart                                       │
│                                                             │
│  5. Verify deployment                                       │
│     └── Test in browser                                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Testing

**Create test file:**

```python
# myapp/selling/doctype/customer/test_customer.py

import frappe
import unittest

class TestCustomer(unittest.TestCase):
    def setUp(self):
        """Set up test data"""
        pass
    
    def tearDown(self):
        """Clean up test data"""
        frappe.db.rollback()
    
    def test_customer_creation(self):
        """Test basic customer creation"""
        customer = frappe.get_doc({
            "doctype": "Customer",
            "customer_name": "Test Customer",
            "email": "test@example.com"
        })
        customer.insert()
        
        self.assertEqual(customer.customer_name, "Test Customer")
        self.assertTrue(customer.name)
    
    def test_email_validation(self):
        """Test email validation"""
        customer = frappe.get_doc({
            "doctype": "Customer",
            "customer_name": "Test",
            "email": "invalid-email"
        })
        
        self.assertRaises(frappe.ValidationError, customer.insert)
    
    def test_credit_limit(self):
        """Test credit limit validation"""
        customer = frappe.get_doc({
            "doctype": "Customer",
            "customer_name": "Test",
            "credit_limit": -100
        })
        
        self.assertRaises(frappe.ValidationError, customer.insert)
```

**Run tests:**

```bash
# Run all tests for app
bench --site mysite.local run-tests --app myapp

# Run tests for specific doctype
bench --site mysite.local run-tests --doctype Customer

# Run specific test file
bench --site mysite.local run-tests --module myapp.selling.doctype.customer.test_customer

# Run with verbose output
bench --site mysite.local run-tests --app myapp -v
```

### Useful Commands Reference

```bash
# ═══════════════════════════════════════════════════════════
# DEVELOPMENT COMMANDS
# ═══════════════════════════════════════════════════════════

# Start development server
bench start

# Watch and auto-build assets
bench watch

# Build assets manually
bench build --app myapp

# Clear all cache
bench --site mysite.local clear-cache

# Clear only website cache
bench --site mysite.local clear-website-cache

# ═══════════════════════════════════════════════════════════
# DATABASE & MIGRATION
# ═══════════════════════════════════════════════════════════

# Run migrations (apply JSON changes)
bench --site mysite.local migrate

# Skip failing patches
bench --site mysite.local migrate --skip-failing

# Open database console
bench --site mysite.local mariadb

# Backup site
bench --site mysite.local backup

# Backup with files
bench --site mysite.local backup --with-files

# ═══════════════════════════════════════════════════════════
# CONSOLE & DEBUGGING
# ═══════════════════════════════════════════════════════════

# Python console with Frappe context
bench --site mysite.local console

# Execute Python function
bench --site mysite.local execute myapp.module.function

# Execute with arguments
bench --site mysite.local execute myapp.api.test --args '["arg1", "arg2"]'

# ═══════════════════════════════════════════════════════════
# EXPORT & IMPORT
# ═══════════════════════════════════════════════════════════

# Export document
bench --site mysite.local export-doc "DocType" "Customer"

# Export fixtures
bench --site mysite.local export-fixtures

# Import fixtures
bench --site mysite.local import-fixtures

# ═══════════════════════════════════════════════════════════
# GIT WORKFLOW
# ═══════════════════════════════════════════════════════════

# After editing files
cd ~/frappe-bench/apps/myapp
git status
git add .
git commit -m "feat: Description of changes"
git push origin main

# On server
cd ~/frappe-bench/apps/myapp
git pull origin main
bench --site prodsite migrate
bench --site prodsite clear-cache
bench restart

# ═══════════════════════════════════════════════════════════
# TROUBLESHOOTING
# ═══════════════════════════════════════════════════════════

# Check scheduler status
bench --site mysite.local scheduler status

# Show pending background jobs
bench --site mysite.local show-pending-jobs

# View error logs
tail -f ~/frappe-bench/logs/frappe.log

# Check bench version
bench version

# Update bench itself
pip install --upgrade frappe-bench
```

---

*For DocType JSON schema, see `07-doctype-json-reference.md`*
*For Python controllers and app structure, see `08-python-controllers-app-structure.md`*
