# Frappe Framework - Bench CLI Commands

## Overview

The `bench` command is the primary CLI tool for managing Frappe sites, apps, and the development environment.

## Site Management

### Create and Delete Sites

```bash
# Create new site
bench new-site mysite.local

# Create with specific database
bench new-site mysite.local --db-name custom_db_name

# Create with admin password
bench new-site mysite.local --admin-password admin123

# Create with source SQL
bench new-site mysite.local --source_sql /path/to/database.sql

# Drop/delete site
bench drop-site mysite.local

# Force drop (skip confirmation)
bench drop-site mysite.local --force

# Archive site
bench drop-site mysite.local --archived-sites-path /path/to/archive
```

### Site Selection

```bash
# Set default site
bench use mysite.local

# Run command on specific site
bench --site mysite.local migrate

# Run on all sites
bench --site all migrate
```

### Backup and Restore

```bash
# Backup site
bench --site mysite.local backup

# Backup with files
bench --site mysite.local backup --with-files

# Backup to specific path
bench --site mysite.local backup --backup-path /path/to/backups

# Restore site
bench --site mysite.local restore /path/to/database.sql.gz

# Restore with files
bench --site mysite.local restore /path/to/database.sql.gz \
    --with-public-files /path/to/public-files.tar \
    --with-private-files /path/to/private-files.tar
```

## App Management

### Install and Remove Apps

```bash
# Get app from git
bench get-app https://github.com/user/app-repo

# Get specific branch
bench get-app https://github.com/user/app-repo --branch develop

# Install app on site
bench --site mysite.local install-app app_name

# Uninstall app from site
bench --site mysite.local uninstall-app app_name

# Remove app from bench
bench remove-app app_name

# List apps on site
bench --site mysite.local list-apps
```

### Creating New App

```bash
# Create new Frappe app
bench new-app my_custom_app

# This creates structure in apps/my_custom_app/
```

## Update Commands

```bash
# Update everything (pull + migrate + build)
bench update

# Pull code only
bench update --pull

# Migrate only (run patches)
bench update --patch

# Build assets only
bench update --build

# Update specific apps
bench update --apps erpnext,myapp

# Reset changes and update
bench update --reset

# Skip backup before update
bench update --no-backup
```

## Development Commands

### Start Development Server

```bash
# Start all services
bench start

# Start with specific workers
bench start --procfile Procfile
```

### Build Assets

```bash
# Build all assets
bench build

# Build specific app
bench build --app myapp

# Build with hard link (faster dev)
bench build --hard-link

# Watch for changes
bench watch
```

### Clear Cache

```bash
# Clear all cache
bench --site mysite.local clear-cache

# Clear website cache
bench --site mysite.local clear-website-cache
```

## Console and Database

```bash
# Python console with Frappe context
bench --site mysite.local console

# Database shell
bench --site mysite.local mariadb

# Execute Python function
bench --site mysite.local execute myapp.module.function

# Execute with arguments
bench --site mysite.local execute myapp.module.function --args '["arg1"]'

# Run Python file
bench --site mysite.local execute frappe.core.doctype.user.user.get_user_info --args '["admin"]'
```

## User Management

```bash
# Add system manager user
bench --site mysite.local add-user user@example.com --first-name John --last-name Doe

# Set admin password
bench --site mysite.local set-admin-password newpassword

# Add user to hosts file
bench --site mysite.local add-to-hosts
```

## Scheduler Commands

```bash
# Enable scheduler
bench --site mysite.local scheduler enable

# Disable scheduler
bench --site mysite.local scheduler disable

# Check scheduler status
bench --site mysite.local scheduler status

# Run scheduler once (for debugging)
bench --site mysite.local execute frappe.utils.scheduler.enqueue_events

# Show pending jobs
bench --site mysite.local show-pending-jobs
```

## Workers and Queue

```bash
# Show running workers
bench show-workers

# Start specific queue worker
bench worker --queue short
bench worker --queue default
bench worker --queue long

# Purge failed jobs
bench --site mysite.local purge-jobs
```

## Database Commands

```bash
# Run SQL query
bench --site mysite.local execute "frappe.db.sql('SELECT * FROM tabUser')"

# Export fixtures
bench --site mysite.local export-fixtures

# Import fixtures
bench --site mysite.local import-fixtures
```

## Migration Commands

```bash
# Run migrate
bench --site mysite.local migrate

# Skip failing patches
bench --site mysite.local migrate --skip-failing

# Rebuild database (careful!)
bench --site mysite.local reinstall

# Build search index
bench --site mysite.local build-search-index
```

## Testing

```bash
# Run all tests for app
bench --site mysite.local run-tests --app myapp

# Run specific doctype tests
bench --site mysite.local run-tests --doctype "Task"

# Run specific module tests
bench --site mysite.local run-tests --module myapp.mymodule.test_module

# Run with verbose output
bench --site mysite.local run-tests --app myapp -v
```

## Configuration Commands

```bash
# Set config value
bench --site mysite.local set-config key value

# Set common config
bench config dns_multitenant on

# Show config
bench --site mysite.local show-config

# Setup production
bench setup production

# Setup supervisor
bench setup supervisor

# Setup nginx
bench setup nginx
```

## Version and Info

```bash
# Show versions of all apps
bench version

# Show Frappe version
bench version --format json

# Show bench help
bench --help

# Show command help
bench new-site --help
```

## Setup Commands

```bash
# Setup bench requirements
bench setup requirements

# Setup Node packages
bench setup node

# Setup Python environment
bench setup env

# Setup Redis
bench setup redis

# Setup Procfile
bench setup procfile

# Setup for production
bench setup production
bench setup supervisor
bench setup nginx
```

## Translation Commands

```bash
# Get untranslated strings
bench --site mysite.local get-untranslated [lang] [output_file]

# Update translations
bench --site mysite.local update-translations
```

## Maintenance Mode

```bash
# Enable maintenance mode
bench --site mysite.local set-maintenance-mode on

# Disable maintenance mode
bench --site mysite.local set-maintenance-mode off
```

## Custom Commands

Add custom commands to your app:

```python
# myapp/commands.py
import click
import frappe
from frappe.commands import pass_context

@click.command('my-command')
@click.option('--param', default='default', help='Parameter')
@pass_context
def my_command(context, param):
    """Custom command description"""
    for site in context.sites:
        frappe.init(site=site)
        frappe.connect()
        # Your logic
        frappe.destroy()

commands = [my_command]
```

```bash
# Run custom command
bench --site mysite.local my-command --param value
```
